# Speaker notes

25-minute speaking allocation, with four backup slides. Timing is an estimate for rehearsal.

## 1. Design and Implementation of a High-Frequency Charge-Pump PFC Resonant Converter for a USB-C Power Supply
*00:00–00:30*

This thesis covers the design and implementation of a USB-C power supply using a high-frequency charge-pump PFC resonant converter. The project adapts the converter to a USB-C load that can be connected and disconnected during operation. This brings startup, no-load operation and changes in demand into the control problem.

The design had to supply changing USB-C loads within a 100-watt continuous power target.

## 2. A USB-C supply for a changing load
*00:30–02:15*

USB-C adapters must deliver higher power to devices in a small volume. The connected device may be absent at startup, connect later, change its demand, or be disconnected. Each state changes the energy balance at the secondary: excess transfer raises the stored voltage, while a connected load draws energy before transfer can increase. Average transferred power therefore has to follow the demand. The project goal was 100 watts of continuous output, with 65 watts as the continuous minimum. These were design goals. The circuit was integrated around the supplied magnetics, and prototypes were built and brought up. Secondary-voltage burst control was developed to manage the operating states. Output and input behavior and surface temperatures were then measured to assess the electrical and thermal limits.

The circuit therefore had to combine input-current shaping, isolated power transfer and control of the energy sent to the load.

## 3. One half bridge drives both power paths
*02:15–04:25*

The supply combines input-current shaping and isolated power transfer around one GaN half bridge. Starting at the AC input, the input bridge supplies the charge pump. The pump transfers charge to the high-voltage link, which buffers the difference between the pulsating input power and secondary demand. The half bridge is supplied by that link, and its switching node drives both the pump and the resonant path. The resonant tank transfers energy through the transformer, and the secondary rectifier supplies the bulk capacitor. The USB-C Power Delivery stage then regulates the selected connector voltage from that bulk supply.

The secondary bulk voltage is sent across the isolation barrier to the MCU. The MCU changes the enabled groups of switching cycles to regulate the bulk voltage. Both power paths therefore respond to the same switching activity. The converter principle and design method came from earlier DTU work by Ammar and colleagues, and the supplied planar magnetics were also developed in earlier DTU work. The complete supply, including its power, sensing, control and USB-C circuits, was integrated for this project.

First, the charge pump shows how the shared switching action shapes the input current.

## 4. Charge transfer shapes the input current
*04:25–06:20*

The rectified input feeds the charge-pump branch. The half bridge drives the switching node shared with the resonant path. During an enabled cycle, the pump capacitor charges and discharges through the inductor and steering paths, transferring charge to the high-voltage link. If the capacitor completes an excursion approximately equal to the rectified input voltage, the charge transferred per enabled cycle is approximately the pump capacitance multiplied by that voltage. Averaged over many carrier cycles, the rectified-input current envelope follows the relationship shown. Here, the barred i is the average rectified-input current, f sub s is the switching frequency, C sub p is the pump capacitance, and v sub rec is the rectified input voltage. The factor b is the local fraction of cycles enabled by the burst schedule. With a constant enabled fraction, the ideal envelope follows the rectified line voltage. If that fraction changes with line phase, the current shape changes too. Actual charge transfer also depends on the available current and clamp timing. The controller therefore affects input current as well as the energy sent to the secondary, which connects this mechanism to the measured power factor later in the presentation.

The same half bridge also drives the isolated resonant branch near one megahertz.

## 5. Resonant transfer runs near 1 MHz
*06:20–08:20*

The same half bridge also drives the isolated resonant path. Its switching node excites the series tank and the transformer primary; the secondary rectifier charges the bulk supply that feeds the USB-C stage. The nominal carrier is about one megahertz. Switching at this frequency can reduce the size of passive components, and the supplied planar inductor and transformer provide a low-profile starting point. These magnetics came from earlier DTU work and were integrated into the converter.

The short switching period also leaves less time for commutation. During dead time, current charges and discharges the half-bridge node capacitances. The current must have the direction and magnitude needed to move the node within the available interval. Both the pump current and the primary resonant current contribute at the shared node; depending on their directions, they can aid or oppose each other. Their sum changes with line voltage, load and burst history. The dead-time choice therefore has to balance sufficient commutation time against additional reverse-conduction loss. The controller determines when switching packets pass energy to the secondary.

For a changing USB-C load, the energy transferred by this carrier is controlled in switching packets.

## 6. Burst control regulates the secondary bulk
*08:20–10:45*

The converter transfers energy in groups of carrier cycles. The controller changes the enabled fraction so that the average energy transferred follows the secondary-bulk voltage. The isolated feedback circuit passes that voltage to the MCU, which adjusts the burst-enable command to the GaN half bridge. The carrier remains near one megahertz within an enabled packet.

The first voltage-feedback implementation waited for each ADC conversion in the foreground. That wait shared time with control updates and communication. The firmware was changed to use circular direct memory access, or DMA, so primary voltage, secondary voltage and half-bridge current samples could be transferred to memory in the background. The control loop can then read the latest available values without waiting for each conversion. The active regulation quantity is secondary-bulk voltage.

The measured switch-node trace at the 5 V, 3 A USB-C operating point shows a packet of switching followed and preceded by idle time. It illustrates the switching activity, while the control law and acquisition method are described by the firmware. Startup uses limited packets and settling intervals to energize the isolated feedback circuit. After load removal, a no-load guard lowers the regulation band and caps duty to limit continued charging. Under load, the commanded duty is adjusted as bulk voltage changes.

The regulated secondary bulk feeds the USB-C stage, which sets the selected connector voltage.

## 7. USB-C voltage follows the selected setting
*10:45–12:25*

The selected USB-C output was tested at fixed settings of five, nine, fifteen and twenty volts. Each marker shows a measured DC-coupled average at the USB-C connector, expressed as a percentage of the selected voltage. The MCU regulated the secondary bulk supply, while the USB-C PD stage regulated the connector voltage to the selected setting. Across the loaded measurements the largest absolute average error was 0.583 percent, at five volts and one ampere. The twenty-volt points extend from a light-load measurement to four high-current points; the markers show only the currents actually measured. These are average-voltage observations, while ripple and transient behaviour require separate measurements.

At the highest twenty-volt point, the connector output can be compared with the AC input power.

## 8. 79.89 W reached the USB-C connector
*12:25–14:10*

At the highest recorded DC-coupled connector point on V1, the selected output was 20 volts and the load current was 4 amperes. The measured average connector voltage was 19.9732 volts, giving 79.8928 watts at the USB-C connector. The associated input instrument logged 104.418 watts at 240 volts AC and 50 hertz. Dividing the connector power by that input reading gives an efficiency estimate of 76.51 percent.

The input-minus-output difference was 24.5252 watts. It is the total difference between those readings; the measurements do not assign it to individual parts of the converter. The input reading differs from a separate power-scope reading, and auxiliary power accounting remains unresolved, so the efficiency is preliminary. The 100 watt continuous target was not reached, and this point was not thermally rated for continuous operation.

The input measurements also show how power factor and current distortion change with load.

## 9. Input current improves with load
*14:10–16:00*

The connector result near 80 watts is accompanied by good input power quality at the high-load points. These plots use the source instrument readings with the USB-C output selected at 20 volts. At 0.25 ampere, the power factor was 0.44 and the current total harmonic distortion was 79.46 percent. At 3.7 and 3.8 amperes, the power factors were 0.97 and 0.98, with current distortion of 2.23 and 2.62 percent. At 4 amperes, the source showed 0.99 and 3.98 percent. The high-load points are therefore close to unity power factor, while the light-load point has much greater distortion. The distortion does increase again within the three high-load points. As discussed earlier, burst timing can change the fraction of enabled switching cycles over the line cycle and so affect input-current shaping. These measurements show the load-dependent behavior but do not isolate that mechanism.

V1 reached nearly 80 watts at the USB-C connector. In V2, heating of the external series inductor led to a tank change.

## 10. V2 removes the hot series inductor
*16:00–18:10*

The connector and input results were measured on V1. V2 integrated the MCU and its control, sensing, local supplies and USB-C output with the power stage. During V2 testing, the external series inductor in the resonant branch became hot. That approximately 9.4 microhenry inductor was removed, and the resonant capacitance was changed to approximately 1.66 nanofarads. The transformer leakage then supplied the series inductance for the tank. The diagrams show leakage as an equivalent part of the transformer, rather than an extra physical inductor. The given transformer measurements were 16.42 and 16.50 microhenries; their mean of 16.46 microhenries and the new capacitance give an ideal series resonance of approximately 0.963 megahertz. The installed resonance still needs measurement. The software dead time was set to about 60 nanoseconds. Half-bridge heating decreased after both tank and timing changes, while heating remained at the input bridge. Switch voltage and current at turn-on are needed to assess zero-voltage switching.

The modified tank was then loaded directly at the secondary to measure its voltage and power as current increased.

## 11. More secondary power came with voltage droop
*18:10–20:30*

After the tank and timing changes, an electronic load was connected directly to the V2 secondary output. Both plots use the same secondary current, so the voltage and power at each load point can be read together. At the first point, 1.86 amperes, the secondary voltage was 26.14 volts and the calculated power was 48.68 watts. As current increased, the voltage fell while the power rose. At 4.29 amperes the voltage was 20.07 volts and the power was 86.17 watts. At the final point, 10.01 amperes, the voltage had fallen to 13.69 volts while the calculated power had risen to 137.08 watts. The higher power was therefore accompanied by substantial voltage droop. The test was made at the secondary, and these readings describe the load sequence at that point in the circuit. The larger current and the voltage behavior also need to be considered with the heating observed during the same sequence.

The temperatures recorded during this sequence show where heating remained.

## 12. Heating remained in the bridge and secondary
*20:30–23:00*

The electronic load was connected directly to the secondary output for this sequence. The load was increased through seven points, from about 48.7 watts to 137.1 watts. The image shows the final point, with the input bridge covered by region R3 and the secondary area by region R1. These are maximum surface temperatures within the marked regions, rather than individual junction temperatures.

The input bridge reached 83.9 degrees Celsius at the second point, at 70.75 watts. At the later, higher-power points, its measured region maximum was between 68.2 and 75.6 degrees. The secondary region rose through the sequence from 50.3 to 98.3 degrees at the final 137.08-watt point. None of the points reached thermal equilibrium, so the plotted readings combine load changes with continued heating. The 137-watt point also had substantial voltage droop, as shown on the previous slide.

The bridge diodes had been replaced, but the heating remained. Limited bridge copper and a possible single-via connection between layers may restrict current and heat paths. A fixed-load thermal run under defined cooling is needed to establish how the temperature develops over time and assess continuous operation.

Voltage droop and continued heating therefore limit continuous USB-C power.

## 13. Continuous USB-C power remains the limit
*23:00–25:00*

The supply was built around the given charge-pump circuit and planar magnetics. The power stage, feedback and USB-C output were integrated, and secondary-voltage burst control was developed. Testing covered connector output, input power quality and temperature. On V1, the highest measured connector point was 79.89 watts. On V2, the hot series inductor was removed and the tank and timing were changed. The later secondary-load test transferred more power, but the secondary voltage fell as current increased and the secondary region continued to heat. None of those load points reached thermal equilibrium. The 100-watt continuous connector target remains to be reached. The next measurement is to hold the 65-watt minimum at the connector while following temperatures to equilibrium, before progressing toward 100 watts.

## 14. V1 switching at the carrier frequency
*Backup*

This V1 capture was taken with the USB-C output set to 20 volts and the electronic load set to 4.7 amps. Yellow is the half-bridge switch-node voltage. The green secondary bulk and blue USB-C VBUS channels are AC-coupled, so their displayed positions are not DC output readings. The horizontal scale is one microsecond per division, and roughly ten switching cycles appear across the ten-microsecond window. The carrier therefore operates at about one megahertz during the displayed interval. The individual transitions can be seen, although this time scale does not resolve the turn-on interval in detail. To assess zero-voltage switching, gate-source and device-voltage waveforms need to be captured together on a calibrated time base; current measurement would also help explain commutation.

## 15. The tank was retuned around transformer leakage
*Backup*

The original design calculation used approximately 9.4 microhenries of external series inductance and one nanofarad of series capacitance. The transformer component measurements gave leakage values of 16.42 and 16.50 microhenries. Their mean, 16.46 microhenries, is used in both columns, giving a total series inductance of 25.86 microhenries and an ideal series resonance of approximately 0.990 megahertz for the original calculation. This one-nanofarad value is the design calculation, not a confirmed fitted value before the V2 change. In V2, the hot external inductor was removed and the capacitance was changed to approximately 1.66 nanofarads. With transformer leakage alone, the same calculation gives approximately 0.963 megahertz. Both estimates are near the nominal one-megahertz carrier. The installed response also depends on load, the magnetizing branch and parasitics; the in-circuit resonance still needs measurement.

## 16. V2 secondary-load measurements
*Backup*

The electronic load was connected directly to the V2 secondary output, before the USB-C PD stage. Secondary power was calculated from the measured secondary voltage and current. As current increased from 1.86 to 10.01 amperes, secondary voltage fell from 26.14 to 13.69 volts and calculated power rose from 48.68 to 137.08 watts. At 20.07 volts and 4.29 amperes, the secondary delivered 86.17 watts. The thermal values are surface-region maxima: R1 covers the secondary and R3 the input bridge. They are not junction temperatures. R3 reached 83.9 degrees Celsius at 70.75 watts; at later points it ranged from 68.2 to 75.6 degrees. R1 rose from 50.3 to 98.3 degrees. These were successive load points and none reached thermal equilibrium, so the temperature readings include continued heating as well as changes in load.

## 17. V2 power circuit and earlier work
*Backup*

The V2 circuit combines the input filter and rectifier, the charge-pump and resonant paths, the GaN half bridge, and the transformer and secondary rectifier. The drawing shows the circuit before the tank change, with the external series inductor still present. The charge-pump conversion principle and analytical design method came from earlier work by Ahmed M. Ammar, Frederik M. Spliid, Yasser Nour, and Arnold Knott. Their papers are “Analysis and Design of a Charge-Pump-Based Resonant AC–DC Converter with Inherent PFC Capability,” IEEE Journal of Emerging and Selected Topics in Power Electronics, 2020, DOI 10.1109/JESTPE.2020.2966143, and “A 1-MHz Resonant LED Driver with Charge-Pump-Based Power Factor Correction,” the same journal, 2021, DOI 10.1109/JESTPE.2021.3083404. The planar transformer and pump inductor were designed by Bima Nugraha Sanusi and the DTU Power Electronics group and measured by Máni Gautason. The supplied magnetics were integrated into the converter, and the hardware, control and prototype testing were developed in this project.
