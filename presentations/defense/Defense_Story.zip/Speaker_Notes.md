# Defense speaker notes

25-minute main talk; five backup slides. Timing is an estimate for rehearsal.

## 1. Design and Implementation of a High-Frequency Charge-Pump PFC Resonant Converter for a USB-C Power Supply
*00:00–00:30*

USB-C power supplies serve devices with different voltage settings and changing power needs. This thesis presents the implementation of a high-frequency charge-pump PFC resonant converter for a USB-C power supply, including its digital control and testing under load.

First, consider the demands placed on USB adapters.

## 2. USB adapters: power range and compact design
*00:30–01:50*

USB adapters serve devices with different power needs. These examples range from a 5 W USB power adapter used with many earlier iPhones to 20 W and 140 W USB-C adapters. A practical adapter also needs a compact form that is convenient to carry and use. USB Power Delivery allows selected output-voltage levels, so the same connector can serve a range of loads. The load may be connected after startup, removed during operation, or draw little power while attached. These conditions matter to the supply because the transferred power must respond as demand changes. The project target was 100 W continuous output, with a continuous minimum of 65 W. These are design objectives for the USB-C power supply. At this power level, both converter size and thermal behavior matter to the practical design.

The next slide considers how switching frequency affects the size and losses of the converter.

## 3. Higher switching frequency brings a loss tradeoff
*01:50–03:15*

For a USB-C adapter, the available space has to accommodate the magnetic components, capacitors, switching devices and their heat paths. Increasing the switching frequency can reduce the size of passive components, which makes a more compact design possible. The benefit comes with a cost: the devices switch more often. Each turn-on and turn-off dissipates energy, so at a fixed energy per transition the average switching loss increases with frequency. That loss becomes heat and can limit efficiency and the power that can be handled in the available volume. The transition energy itself also depends on the operating conditions and the circuit, so frequency alone does not set the total loss. Winding loss, conduction loss and other losses also need attention. Reducing the energy lost at each transition therefore becomes important when operating at high frequency.

One way to reduce the turn-on part of that loss is zero-voltage switching.

## 4. ZVS reduces turn-on loss
*03:15–04:45*

At high switching frequency, reducing the energy lost at each transition becomes important. Zero-voltage switching uses current already flowing in the circuit to move the switch node before the incoming device turns on. For this low-side transition, the high-side device turns off first. During the dead time, current leaving the switch node charges the upper device capacitance and discharges the lower one. The low-side drain-to-source voltage falls close to zero, and the low-side gate is then turned on. This reduces the voltage and current overlap at turn-on and therefore reduces turn-on loss. The current needs the correct direction and enough time to move the charge. Its magnitude changes with circuit and load conditions, so a resonant converter still needs control as the load changes. The diagram shows the intended timing; the measured switch-node waveform is presented later.

The chosen architecture combines a charge-pump input stage with an isolated resonant converter for the USB-C supply.

## 5. Charge-pump PFC feeds an isolated USB-C supply
*04:45–06:10*

The supply combines a charge-pump input stage with an isolated resonant converter and a USB-C output stage. The AC bridge supplies the rectified mains to the charge pump, which transfers charge to the DC link. The link supplies the half bridge. Its switching node drives both the charge pump and the separate resonant output path. The pump shapes the input current without a separate dedicated PFC current loop. The resonant path transfers energy through the transformer, and the secondary rectifier produces the bulk voltage. The MCU regulates this bulk supply using burst control. The downstream USB-PD stage regulates the connector voltage to the selected level. The topology and supplied magnetic designs came from earlier DTU work by Ammar and colleagues. The work presented here covers the board, control, integration and tests around that starting point.

References: A. M. Ammar et al., “Analysis and Design of a Charge-Pump-Based Resonant AC–DC Converter with Inherent PFC Capability,” IEEE JESTPE, 2020, doi:10.1109/JESTPE.2020.2966143; A. M. Ammar et al., “A 1-MHz Resonant LED Driver with Charge-Pump-Based Power Factor Correction,” IEEE JESTPE, 2021, doi:10.1109/JESTPE.2021.3083404.

The charge-transfer path can now be considered in more detail.

## 6. Charge transfer shapes the input current
*06:10–07:50*

The charge pump is connected between the rectified input, the DC link and the shared half-bridge switch node. C24 is the pump capacitor and L3 is the pump inductor. During each enabled cycle the half bridge drives the pump through charge-transfer and clamp intervals. In the ideal sequence the capacitor voltage moves approximately from zero to the instantaneous rectified line voltage, so the charge transferred per active cycle is approximately Cₚ times that voltage. Multiplying this charge by the switching frequency gives an average current proportional to the rectified line voltage, without a separate dedicated PFC current loop. The actual input current is made up of pulses, and L3 affects their slope and the time needed to complete transfer. Burst operation changes the fraction of active cycles. A constant local burst density scales the ideal envelope; a density that changes over the line cycle can also change its shape. Clamp timing and incomplete excursions affect the actual current. This pump arrangement follows the earlier DTU topology of Ammar and colleagues.

Reference: A. M. Ammar, F. M. Spliid, Y. Nour and A. Knott, “A 1-MHz Resonant LED Driver with Charge-Pump-Based Power Factor Correction,” IEEE J. Emerging and Selected Topics in Power Electronics, vol. 9, no. 5, pp. 5838–5850, 2021, doi: 10.1109/JESTPE.2021.3083404.

The same switch node also drives the resonant path that supplies the isolated secondary.

## 7. The resonant path supplies the isolated bulk voltage
*07:50–09:20*

The resonant output path starts at the same half-bridge switching node as the charge pump. The series capacitor and inductor work with the transformer leakage inductance to form the tank. The transformer transfers energy across the isolation barrier and steps the voltage down. On the secondary side, the full-wave rectifier charges the bulk capacitor, which buffers the energy and supplies the USB-C power-delivery stage. The two branch currents are coupled through the shared switching node. With the current directions shown, the half-bridge current is the signed sum of the pump and resonant-path currents. Their instantaneous sum determines the current available to charge and discharge the switch-node capacitances during commutation. Both branches therefore affect the switching transition. The MCU regulates the secondary bulk voltage through the converter drive, and the PD stage regulates the connector voltage to the selected level. The tank change made during V2 testing is discussed with the results.

The load changes the energy drawn from the bulk, so the converter drive needs to respond to the bulk voltage.

## 8. Secondary-voltage feedback sets burst duty
*09:20–11:20*

The resonant stage supplies the secondary bulk, and its voltage is fed back to the MCU. The controller compares that voltage with the bulk reference and changes the average burst-enable duty. During enabled intervals the half bridge continues to switch at 1 MHz, so the amount of transferred energy is adjusted without moving the carrier frequency.

Under load, the stored duty is trimmed according to the bulk voltage. When the voltage falls below the lower threshold, the request is increased; above the upper region it is reduced. At light or no load, the controller uses hysteresis and a lower duty cap to limit further charging. When demand returns, the cap can be released.

At startup, small bounded energy packets are separated by settling intervals while the secondary supply builds. For overvoltage, the control can request low duty or enter a holdoff until the rearm condition is reached; an active fault inhibits switching. These functions were combined in the MCU control to manage energy transfer across operating conditions. The USB-C PD stage then regulates the connector voltage to the selected level.

The next capture shows how burst operation appears at the switch node.

## 9. V1 switching changes with the operating point
*11:20–13:00*

The V1 switch-node voltage shows how the switching is grouped at different operating points. At the 5 V setting with a 3 A load, the first capture shows an idle interval, followed by a packet of switching cycles and then the node ringing toward an intermediate voltage. At the 20 V setting with a 4 A load, switching continues across the entire displayed 100 microseconds. The two captures use different horizontal scales, as shown beside them. During active switching the carrier is approximately 1 megahertz. Changing the time for which the carrier is enabled changes the average energy supplied to the secondary; the two frames show the switching activity at these operating points.

The next capture expands the individual switching cycles.

## 10. V1 switching at approximately 1 MHz
*13:00–14:30*

This capture shows the V1 converter at a 20 V USB-C setting with a 4.7 A load. The yellow trace is the half-bridge switch node. The green and blue traces show the secondary output and USB-C VBUS with AC coupling. The switch node moves between its two levels at approximately 1 MHz, with the individual transitions visible in the capture. No gate signal was recorded in this capture. A simultaneous gate-source and device-voltage measurement is needed to determine the voltage at turn-on and assess zero-voltage switching.

The next result is the voltage delivered at the USB-C connector.

## 11. V1 delivered 79.89 W at USB-C
*14:30–16:00*

The V1 output was tested at the USB-C connector with a 240 volt, 50 hertz input. The table shows the selected loaded point for each fixed output voltage. At five, nine and fifteen volts, the electronic load was set to three amps; at twenty volts it was set to four amps. In each case the measured average VBUS stayed close to the selected voltage. Across the loaded points, the largest absolute average-voltage error was 0.583 percent, at five volts and one amp. At the twenty-volt, four-amp point, the average VBUS was 19.9732 volts. Multiplying this by the load setting gives 79.89 watts at the USB-C connector.

The input and output power at this point also give an initial efficiency estimate.

## 12. Efficiency estimate was 76.51% at 79.89 W
*16:00–17:30*

The connector result can also be compared with the real power drawn at the AC input. At the 20 V setting and 4 A load, the average connector voltage was 19.9732 V. This gives 79.8928 W at the USB-C output, compared with 104.418 W at the input. The resulting efficiency estimate is 76.51%, and the input–output power difference is 24.53 W. The plot shows the eleven selected operating points across the four voltage settings. The 9 V points give estimates from 83.56% to 86.82%; the three higher-power 20 V points are approximately 77%. These are initial efficiency estimates, with input/output timing and auxiliary power still to be checked.

The same input measurements also show how power factor and current distortion change with load.

## 13. Input power quality improved at higher load
*17:30–19:00*

The input measurements show how the charge-pump PFC stage behaved at the 20 volt USB-C setting. At the light-load point of 0.25 amps, the recorded power factor was 0.44 and current THD was 79.46 percent. At 3.7 and 3.8 amps, power factor was 0.97 and 0.98, with current THD of 2.23 and 2.62 percent. At the 4 amp point just discussed, the power factor reached 0.99 and the instrument displayed 3.98 percent current THD. The high-load points therefore show a substantially better overall input-quality result than the light-load point, although distortion rises across these three high-load measurements. These results show the input-quality behavior of the converter without a separate dedicated PFC current loop, and also show the limitation at light load.

The next change addressed heating in the resonant tank of the second prototype.

## 14. V2 tank uses transformer leakage alone
*19:00–20:40*

The V2 tank initially had an external series inductor in addition to the transformer leakage inductance. The external inductor became hot during loading, so it was removed. The resonant capacitance was changed to approximately 1.66 nanofarads, allowing the tank to use the transformer leakage as its series inductance. The given transformer measurements were 16.42 and 16.50 microhenries. Using their mean of 16.46 microhenries and the new capacitance gives a calculated ideal resonance of approximately 0.963 megahertz. The software dead time was set to approximately 60 nanoseconds. After the tank and timing changes, half-bridge heating decreased. The input-bridge diodes were replaced, but heating around the bridge remained.

The next slide shows the modified converter's secondary output as the load increased.

## 15. V2 secondary power increased as voltage fell
*20:40–22:20*

After the tank change, the electronic load was connected to the V2 secondary output, with approximately 240 volts AC at 50 hertz at the input. The two plots show seven successive readings as the load current was increased. The power is calculated from the secondary voltage and current. At 4.29 amps, the secondary voltage was 20.07 volts and the calculated power was 86.17 watts. At 10.01 amps, the power had increased to 137.08 watts, while the voltage had fallen to 13.69 volts. The converter could transfer more than 100 watts to the secondary load, but the higher power was not delivered at a maintained voltage. The load was connected before the USB-C PD stage, so these are secondary output results.

The thermal images show what happened to the input bridge and secondary regions during the same increasing-load sequence.

## 16. V2 secondary region reached 98.3 °C
*22:20–24:00*

The thermal images show how the two regions changed during the increasing secondary-load sequence. The secondary region R1 rose from 50.3 to 98.3 degrees Celsius at the final point. The input bridge region R3 reached its highest recorded maximum of 83.9 degrees earlier, at about 70.75 watts, and was between 68.2 and 75.6 degrees at the later points. These are maxima in the marked regions, not junction temperatures. The connected points include both changes in load and continued heating. None of the load points reached thermal equilibrium. The secondary rectifier current paths and thermal paths need further work.

With those limits in mind, the final slide brings together the control contribution and the measured output.

## 17. USB-C conversion with digital burst control
*24:00–25:00*

The project integrated the earlier DTU charge-pump PFC topology and supplied magnetics into a USB-C power supply. The V2 board brought the MCU, power stage, sensing and USB-C PD circuit together. The MCU uses burst control to regulate the secondary bulk voltage, while the PD stage regulates the selected USB-C output voltage.

V1 delivered 79.89 watts at the USB-C connector. V2 reached 137.08 watts at a secondary load, but the voltage fell as the load increased and the secondary region continued to heat. The 100 W continuous target remains to be reached. The practical limit remains the combination of voltage droop and heating at higher load.

## 18. V1 connector regulation across the load sweep
*Backup*

This plot shows the average voltage at the V1 USB-C connector relative to the selected output voltage. The lower three settings were measured at 1, 2 and 3 amps. At 20 volts, the measurements include a 0.25 amp light-load point and four points from 3.7 to 4 amps. The largest absolute error was 0.583 percent at 5 volts and 1 amp, where the measured average was 5.02913 volts. At 20 volts and 4 amps the average was 19.9732 volts, an error of minus 0.134 percent. These are average-voltage results; ripple and transient behaviour need separate measurements.

## 19. Efficiency and input quality at selected operating points
*Backup*

These selected operating points put connector power, input power, efficiency estimate and input quality on the same table. Connector power was calculated from average USB-C voltage and load current, and efficiency was estimated from connector power divided by input real power. At 4 A, the instrument displayed 3.98% THD; reconstruction from recorded harmonics gives about 4.53%. These are initial efficiency estimates, with input/output timing and auxiliary power still to be checked.

## 20. V2 secondary power rose as voltage fell
*Backup*

An electronic load was connected to the V2 secondary at approximately 240 volts AC and 50 hertz input. As the secondary current rose from 1.86 to 10.01 amps, its voltage fell from 26.14 to 13.69 volts and calculated power reached 137.08 watts. The secondary region R1 maximum rose from 50.3 to 98.3 degrees Celsius. The highest input-bridge region R3 reading was 83.9 degrees at the 70.75 watt point.

Q: Is 137.08 W the USB-C output or a continuous rating?
A: It is a calculated secondary-load power reading, before the USB-C PD stage. Voltage was falling and the hardware was still heating, so it is not a continuous rating.

Q: Do the temperatures represent device junction temperatures?
A: No. They are thermal-image region maxima: R3 covers the input bridge and R1 covers the secondary area.

Q: How was secondary power calculated?
A: The electronic-load voltage and current were multiplied using the unrounded readings, then rounded to two decimal places.

## 21. Tank resonance with and without the external inductor
*Backup*

The original design calculation used about 9.4 microhenries of external series inductance and 16.5 microhenries of transformer leakage. With a design capacitance of 1 nanofarad, the ideal series resonance is about 0.989 megahertz. In V2, the external inductor was removed after it became hot, and the capacitance was changed to approximately 1.66 nanofarads. The two given transformer leakage measurements were 16.42 and 16.50 microhenries. Their mean of 16.46 microhenries gives an ideal resonance of approximately 0.963 megahertz. These calculated resonances are separate from the 1 megahertz switching carrier. The in-circuit resonance remains to be measured.

## 22. V2 power schematic and topology references
*Backup*

The AC input is filtered and rectified before the charge-pump and resonant stage. The half bridge drives both the charge-pump branch and the isolated resonant path. The secondary rectifier supplies the bulk voltage, which the MCU regulates using burst control. The USB-C PD stage regulates the selected connector voltage. The drawing shows L4 in the original tank; it was removed during V2 testing after it became hot.

The charge-pump conversion principle, analytical design method and planar-magnetics designs came from the earlier work by Ammar and colleagues. The board was designed and assembled around the supplied magnetics, and the control, feedback, local supplies and USB-C output were integrated for V2. The assembled supply was tested for output behaviour, input power quality and surface temperature.

References: Ahmed M. Ammar, Frederik M. Spliid, Yasser Nour, and Arnold Knott, “Analysis and Design of a Charge-Pump-Based Resonant AC–DC Converter with Inherent PFC Capability,” IEEE Journal of Emerging and Selected Topics in Power Electronics, vol. 8, no. 3, pp. 2067–2081, 2020, doi: 10.1109/JESTPE.2020.2966143.

Ahmed M. Ammar, Frederik M. Spliid, Yasser Nour, and Arnold Knott, “A 1-MHz Resonant LED Driver with Charge-Pump-Based Power Factor Correction,” IEEE Journal of Emerging and Selected Topics in Power Electronics, vol. 9, no. 5, pp. 5838–5850, 2021, doi: 10.1109/JESTPE.2021.3083404.
