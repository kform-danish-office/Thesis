"""Validate the generated defense against accepted text and original measurements."""
from pathlib import Path
from io import BytesIO
import csv,hashlib,json,re,zipfile
from lxml import etree
from pptx import Presentation
import fitz

R=Path(__file__).resolve().parent;NAME='Thesis_Defense_Supervisor_Story'
manifest=json.loads((R/'review/slide-manifest.json').read_text())
prs=Presentation(R/(NAME+'.pptx'));pdf=fitz.open(R/(NAME+'.pdf'))
assert len(prs.slides)==len(pdf)==len(manifest['slides'])==22
assert sum(s['section']=='main' for s in manifest['slides'])==17
assert len({s['owner'] for s in manifest['slides']})==22
assert abs(prs.slide_width/prs.slide_height-16/9)<1e-6

def norm(s):
    for a,b in {'Pₛw':'Psw','Eₒₙ':'Eon','Eₒff':'Eoff','f₀':'f0','īᵣₑ꜀':'īrec','vᵣₑ꜀':'vrec','fₛ':'fs','Cₚ':'Cp','Lₚ':'Lp','Cₛ':'Cs'}.items():s=s.replace(a,b)
    return re.sub(r'\s+','',s).lower()
def strings(obj):
    if isinstance(obj,str):return [obj]
    if isinstance(obj,list):return [t for x in obj for t in strings(x)]
    if isinstance(obj,dict):return [t for k,x in obj.items() if k in ['text','columns','rows','title','items'] for t in strings(x)]
    return []
counts=dict(charts=0,tables=0,text_shapes=0,pictures=0);time=0;words=0;missing=[]
notes=['# Defense speaker notes','','25-minute main talk; five backup slides. Timing is an estimate for rehearsal.','']
ids=[s['slide_id'] for s in manifest['slides']]
for ix,(slide,item,page) in enumerate(zip(prs.slides,manifest['slides'],pdf)):
    sid=item['slide_id'];path=R/'proposals'/f'{sid}.json';p=json.loads(path.read_text())
    assert item['text_judgment']=='Accept',(sid,item['text_judgment'])
    assert item['model']=='gpt-6.1-terra' and item['reasoning_effort']=='ultra'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['proposal_sha256'],('Unreviewed proposal',sid)
    assert p['title'] in [sh.text for sh in slide.shapes if sh.has_text_frame]
    expected=p['speaker_notes']
    if p.get('transition') and p['transition'] not in expected:expected+='\n\n'+p['transition']
    if p.get('references_note'):expected+='\n\n'+p['references_note']
    assert slide.notes_slide.notes_text_frame.text==expected,('Notes differ',sid)
    assert not re.search(r'/workspace/|sediment://|SHA-256|TRANSFER_MANIFEST',expected)
    t0=time
    if item['section']=='main':time+=p['duration_seconds'];words+=len(expected.split())
    stamp=f'{t0//60:02}:{t0%60:02}–{time//60:02}:{time%60:02}' if item['section']=='main' else 'Backup'
    notes.extend([f'## {ix+1}. {p["title"]}',f'*{stamp}*','',expected,''])
    texts=[]
    for sh in slide.shapes:
        counts['charts']+=int(sh.has_chart);counts['tables']+=int(sh.has_table)
        counts['text_shapes']+=int(sh.has_text_frame);counts['pictures']+=int(sh.shape_type==13)
        if sh.has_text_frame:texts.append(sh.text)
        if sh.has_table:texts.extend(cell.text for cell in sh.table.iter_cells())
        if sh.has_chart:texts.extend(sh.chart._chartSpace.itertext())
        if sh.has_text_frame or sh.has_table or sh.has_chart or sh.shape_type==13:
            assert sh.left>=0 and sh.top>=0 and sh.left+sh.width<=prs.slide_width+12700 and sh.top+sh.height<=prs.slide_height+12700,('Off canvas',sid)
    joined=norm(' '.join(texts))
    visible=p['visible_content']
    if isinstance(visible,list):blocks={b['id']:b for b in visible}
    else:blocks=visible
    for key,value in blocks.items():
        if 'ticks' in key or 'embedded_labels' in key or key=='body' and isinstance(value,str) and value.startswith('Intentionally'):continue
        for val in strings(value):
            if norm(val) not in joined:missing.append((sid,key,val))
    for block in page.get_text('dict')['blocks']:
        for line in block.get('lines',[]):
            for span in line['spans']:
                assert '\ufffd' not in span['text'] and '\u25a1' not in span['text'],('Missing glyph',sid,span['text'])
                x0,y0,x1,y1=span['bbox']
                assert x0>=-1 and y0>=-1 and x1<=page.rect.width+1 and y1<=page.rect.height+1,('PDF text outside page',sid,span['text'])
assert not missing,('Missing approved visible content',missing)
assert time==1500
with zipfile.ZipFile(R/(NAME+'.pptx')) as z:
    assert z.testzip() is None
    embedded={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('ppt/media/')}
    with zipfile.ZipFile(R/'template/DTU_Blue_base.pptx') as template:
        parts=[n for n in template.namelist() if n.endswith('.xml') and n.startswith(('ppt/slideMasters/','ppt/slideLayouts/','ppt/theme/'))]
        canon=lambda b:etree.tostring(etree.fromstring(b),method='c14n')
        for n in parts:assert canon(z.read(n))==canon(template.read(n)),('Changed DTU part',n)
for n in ['v1_scope_5v_3a.png','v1_scope_20v_4a.png','v1_scope_20v_4p7a.png','thermal_final.jpg','schematic_pump_detail.png','v2_complete_power_schematic.png','adapter_5w.jpg','adapter_20w.jpg','adapter_140w.jpg']:
    assert hashlib.sha256((R/'assets'/n).read_bytes()).hexdigest() in embedded,('Altered/missing original image',n)
for n in ['v1_board.png','v2_board.png','v2_boards_crop.png']:
    if (R/'assets'/n).exists():assert hashlib.sha256((R/'assets'/n).read_bytes()).hexdigest() not in embedded,('Board picture in deck',n)

def charts(sid):return [sh.chart for sh in prs.slides[ids.index(sid)].shapes if sh.has_chart]
def cache(series,tag):return {int(p.get('idx')):float(p[0].text) for p in series._element.xpath(f'./c:{tag}/c:numRef/c:numCache/c:pt')}
with (R/'assets/v2_summary.csv').open() as f:v2=list(csv.DictReader(f))
for ch,field in zip(charts('s15'),['secondary_voltage_V','secondary_power_W']):
    s=ch.series[0];xs=cache(s,'xVal');ys=cache(s,'yVal')
    assert all(abs(xs[k]-float(row['secondary_current_A']))<1e-9 and abs(ys[k]-float(row[field]))<1e-8 for k,row in enumerate(v2))
for s,field in zip(charts('s16')[0].series,['secondary_R1_max_C','bridge_R3_max_C']):
    xs,ys=cache(s,'xVal'),cache(s,'yVal')
    assert all(abs(xs[k]-round(float(row['secondary_power_W']),2))<1e-9 and abs(ys[k]-float(row[field]))<1e-9 for k,row in enumerate(v2))
with (R/'assets/v1_dc_operating_points.csv').open() as f:dc={r['test_id']:r for r in csv.DictReader(f)}
reg=charts('b01')[0];npoints=0
for s in reg.series:
    setting=float(s.name.split()[0]);expected={float(r['iout_a']):float(r['voltage_error_percent_derived']) for r in dc.values() if float(r['pdo_v'])==setting and float(r['iout_a'])>0}
    xs,ys=cache(s,'xVal'),cache(s,'yVal');actual={xs[k]:v for k,v in ys.items()}
    assert actual.keys()==expected.keys();assert all(abs(actual[k]-expected[k])<1e-10 for k in expected);npoints+=len(actual)
assert npoints==14
for ch,field in zip(charts('s13'),['pf','ithd_percent']):
    assert list(ch.series[0].values)==[float(dc[k][field]) for k in ['PDO20-5W-001','PDO20-75W-001','PDO20-76W-38A-001','PDO20-80W-40A-001']]
# Efficiency series are rounded to the reviewed source table's two-decimal precision.
with (R/'assets/v1_efficiency.csv').open() as f:eff=list(csv.DictReader(f))

verified_eff=0
for trace,group in zip(charts('s12')[0].series,json.loads((R/'proposals/s12.json').read_text())['visual']['series']):
    xs,ys=cache(trace,'xVal'),cache(trace,'yVal');actual=sorted((xs[k],v) for k,v in ys.items())
    assert actual==sorted(map(tuple,group['points']))
    setting=float(trace.name.split()[0]);source=sorted((round(float(r['pout_w_derived']),2),round(float(r['efficiency_percent_derived']),2)) for r in eff if float(r['pdo_v'])==setting and r['efficiency_screening_included']=='True')
    assert actual==source,('Efficiency source mismatch',trace.name,actual,source)
    verified_eff+=len(actual)
assert verified_eff==11
for chart,expected_count in [(reg,14),(charts('s12')[0],11)]:
    with zipfile.ZipFile(BytesIO(chart.part.chart_workbook.xlsx_part.blob)) as z:
        sheet=etree.fromstring(z.read('xl/worksheets/sheet1.xml'));ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        cells=[c for c in sheet.findall('.//s:c',ns) if c.get('r')[0] in 'BDFH' and c.get('r')[1:]!='1' and c.find('s:v',ns) is not None]
        assert len(cells)==expected_count
baseline=R/'review/thesis-baseline.json';changes=[]
if baseline.exists() and Path('/workspace/thesis').exists():
    for r in json.loads(baseline.read_text()):
        p=Path('/workspace/thesis')/r['path']
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:changes.append(r['path'])
    assert not changes,changes
(R/'Speaker_Notes.md').write_text('\n'.join(notes))
result={'slides':22,'main_slides':17,'backups':5,'dedicated_terra_ultra_writers':22,'duration_seconds':time,'notes_word_count_including_references':words,'timing':'Estimate including figure walkthroughs and pauses; no live rehearsal',
'editable_objects':counts,'package_crc':'passed','accepted_visible_content_present':True,'notes_exact':True,'template_parts_preserved':len(parts),'v1_regulation_points_verified':npoints,'v1_efficiency_points_verified':verified_eff,'v2_points_verified':7,'chart_blank_cells_preserved':True,'original_measurement_images_preserved':True,'pcb_images_in_deck':False,'thesis_source_changes':changes,'rendering':'LibreOffice; Arial substituted by metric-compatible Liberation Sans','powerpoint_native_inspection':False,'missing_glyphs':False,'off_page_text':False}
(R/'review/validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
