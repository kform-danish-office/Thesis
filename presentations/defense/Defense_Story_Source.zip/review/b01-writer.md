# b01 writer review

- Fourteen loaded DC connector-voltage points were selected from the processed data: three each at 5 V, 9 V and 15 V and five at 20 V. Error values were recalculated with decimal arithmetic and checked against the processed values.
- The greatest absolute error is +0.5826%, rounded to 0.583%, at the 5 V, 1 A point (5.02913 V measured average). At 20 V, 4 A, the average is 19.9732 V and error −0.134%.
- The plotted quantity is average USB-C connector voltage relative to the selected voltage. No AC-detail 4.7 A point or derived power was added. Limitations of input-power records at 15 V/2–3 A and 20 V/3.9 A do not remove their recorded VBUS values from this plot.
- Use editable XY scatter markers without connecting lines. The 20 V points at 3.7–4.0 A need visual inspection after rendering to confirm that each remains distinguishable. Main allocation is 0 s; notes are for an approximately 60 s response to questions.

Sources: `/workspace/thesis/Chapters/10_Results/03_Steady_State.tex`; `/workspace/thesis/Data/measurements/processed_rewrite/dc_operating_points.csv`.
