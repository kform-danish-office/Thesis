# s13 writer review

The four 20 V settings use the directly logged ITECH PF and current THD readings. At 0.25, 3.7, 3.8 and 4.0 A, PF is 0.44, 0.97, 0.98 and 0.99; THD is 79.46%, 2.23%, 2.62% and 3.98%. The 3.9 A row repeats an associated input measurement and is excluded. Categorical charts show measured settings and direct labels, without interpolation or a monotonic THD claim. The result is described as an overall high-load comparison against 0.25 A, not a general law across all operating conditions.

The thesis identifies an unresolved difference between the 3.98% displayed THD at 4 A and approximately 4.53% reconstructed from the harmonic table; this remains in the external checks and is to be addressed in the backup discussion. The prior slide already covers efficiency, so it is not repeated. The following slide develops the V2 tank change. All requested content, chart labels, source mappings and the 90-second allocation are in the proposal.

Revision 2 removes the harmonic-table discrepancy from the main-slide speaker notes while retaining the 3.98% displayed reading.
