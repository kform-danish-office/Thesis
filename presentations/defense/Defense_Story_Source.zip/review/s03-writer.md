# s03 factual review

- Motivation: the thesis states that megahertz switching can reduce passive size, while winding loss and parasitic impedance become more significant (Introduction, Motivation). The diagram is qualitative and makes no claim about measured adapter size or the achieved density of this project.
- Switching loss: Background, High-Frequency GaN Switching gives Psw ≈ fs(Eon + Eoff). The diagram states the fixed-transition-energy condition. Speaker notes explicitly retain the dependence of transition energy on operating conditions and other losses.
- Lead-in: zero-voltage switching reduces turn-on loss, as stated in the same background section. Its commutation mechanics and operating conditions are reserved for s04; no claim is made about observed ZVS in the prototype.
- Notes and transition contain approximately 140 words for the 85-second allocation. Diagram components and equation are specified as native editable shapes and text; no passive-size data or quantitative loss curve is invented.
- No unresolved factual questions.
