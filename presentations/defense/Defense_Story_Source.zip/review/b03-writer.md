# b03 writer factual review — revision 2

- The seven secondary-voltage, secondary-current, calculated-power and R3/R1 region-maximum rows agree with the summary CSV and thesis table. Power was calculated from unrounded voltage and current before rounding to two decimals.
- The electronic load was connected to the V2 secondary. The 137.08 W point is neither a USB-C connector reading nor a continuous rating. Input was approximately 240 V AC at 50 Hz.
- R3 is the input-bridge region and R1 the secondary region. Both displayed temperatures are thermal-image region maxima, not junction temperatures. None of the load points reached thermal equilibrium. The sequence combines changes in load with heating, so it is not a set of settled temperatures.
- No oscilloscope values, input power, efficiency, editorial markers or footnote flags are included. The non-monotonic R3 values are retained exactly.
- Backup slide: zero main-talk seconds; about 45 seconds when presented. All table cells are specified for native PowerPoint editing. Q&A notes address measurement location, continuous operation, region maxima and calculation.
- Sources: `/workspace/thesis/Chapters/10_Results/17_V2_Secondary_Load_Tests.tex`, `/workspace/thesis/Data/measurements/v2_load_thermal/summary.csv`, and `/workspace/thesis/Data/measurements/v2_load_thermal/load_table.tex`.
- Unresolved: none.

- Revision 2 removes administrative capture IDs from the visible table while retaining all seven readings in sequence. Q&A is included directly in speaker notes; the independent backup slide has no transition.
