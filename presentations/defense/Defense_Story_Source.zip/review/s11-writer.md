# s11 writer review

The connector output is calculated from the measured 19.9732 V mean VBUS and the 4.0 A electronic-load setting: 79.8928 W, shown as 79.89 W. The selected voltage table reproduces the four highest tested current settings per output voltage in the steady-state results. Across all 14 loaded DC points, the largest absolute average-voltage error is +0.5826% at 5 V, 1 A, rounded to 0.583%. Input conditions are 240 V AC, 50 Hz.

The 65 W minimum and 100 W continuous target are identified as objectives. The recorded operating point does not give a continuous rating. The 4.7 A AC-coupled capture does not supply a matching DC output voltage and is not used to claim a 94 W DC result. Average-voltage regulation is distinct from ripple and transient behaviour. The efficiency estimate follows on s12 and is not repeated here.

Sources: `/workspace/thesis/Chapters/10_Results/03_Steady_State.tex`, `/workspace/thesis/Data/measurements/processed_rewrite/dc_operating_points.csv`, and `/workspace/thesis/Chapters/01_Introduction/02_Problem_Statement.tex`. The proposal uses editable native text and table cells. No unresolved material factual issue.
