# s15 writer review

The seven current, voltage and calculated power points were checked against the V2 load and thermal summary and the thesis load-test section. Power is voltage multiplied by current; the third point rounds to 86.17 W at 20.07 V and 4.29 A and the final point to 137.08 W at 13.69 V and 10.01 A. The electronic load was connected to the V2 secondary output at approximately 240 V AC and 50 Hz input. This is before the USB-C PD stage.

Two native editable XY charts with separate voltage and power scales show the seven successive readings and the rise in power alongside voltage droop. The headline and notes do not treat the result as connector power or a continuous rating. The next slide handles the thermal sequence and continuing heating. The 100-second allocation includes time to point out the two marked operating points and transition.
