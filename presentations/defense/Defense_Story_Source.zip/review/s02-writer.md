# s02 writer factual review — revision 2

The revised plan criteria give a 100 W continuous target and 65 W continuous minimum. The thesis describes selected USB-C output settings and startup, attachment, removal, and no-load behavior. The project objectives are distinct from the commercial product ratings.

Apple's support page identifies the 5 W USB power adapter and says most iPhone models before iPhone 11 included one. Apple's product pages identify the 20 W and 140 W USB-C power adapters. Their genuine product images and download URLs are in the local asset folder and adapter-photo-downloads.json. The 5 W unit is not labelled USB-C. The photos have different framing and must not be treated as a common-scale comparison; their purpose is to show the range of adapter ratings, not a historical timeline or the size of the project hardware.

The following slide explains the frequency, passive-size, and loss tradeoff; this slide sets the application and target without duplicating that explanation. The estimated 80 seconds includes time to point out the product examples.
