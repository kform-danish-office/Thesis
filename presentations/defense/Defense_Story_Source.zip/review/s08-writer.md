# s08 writer factual review

- The MCU changes average burst-enable duty from secondary-bulk feedback while the active carrier stays at 1 MHz. The USB-C PD stage regulates the selected connector voltage separately; see control objectives and the control contribution discussion.
- Loaded operation increases requested transfer below the lower threshold and reduces stored duty above the upper region. The summing junction is a functional abstraction, not a claim that the implemented control is a conventional linear controller; see voltage control logic.
- Startup alternates bounded energy packets and settling. No-load operation limits duty and can release that limit when demand returns. Soft overvoltage holdoff requests low duty (zero by default) until rearm; faults inhibit transfer; see state machine and open-circuit safety.
- This slide does not claim measured transient performance. The following slide owns the actual burst capture.
- Three bullets contain 21 words excluding labels. Diagram boxes, connections and signs should remain editable. The proposal is ready for Astra's exact-text review.
