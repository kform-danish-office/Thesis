# s12 factual review

The 11 chart pairs were checked against `efficiency_table.tex` and the included rows in `efficiency_screening.csv`. Output power uses average VBUS times load current; efficiency divides that power by AC real input power. The selected 20 V / 4 A point has 19.9732 V, 79.8928 W at the USB-C output, and 104.418 W input: 76.51248% and 24.5252 W difference, rounded to 76.51% and 24.53 W.

Use a marker-only chart because the measurements are selected points with different instruments and operating histories. The slide calls them estimates; the notes give one local explanation of the uncertainty in simultaneous readings and auxiliary-power inclusion. Several selected groups have unresolved instrument disagreement, documented in the source. No component-level loss allocation is supported. The point labels and series are explicit in the proposal.

The previous slide delivers the connector result; this slide interprets its input/output power; the next treats input power quality. The source thesis, datasets and shared deck were read-only.

Revision 2: Shortened the final notes to the requested single sentence; accepted visible content and chart data are unchanged.
