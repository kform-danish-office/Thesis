# b02 writer factual review

Proposal: `proposals/b02.json`, revision 2. The backup slide contains five selected V1 rows with measured average USB-C voltage, load current, calculated connector power, measured input power, initial efficiency estimate, input PF and current THD. All input power, PF and THD values in these selected rows use the ITECH instrument, avoiding a mixed-instrument PF/THD pairing.

| Test ID | VBUS (V) | Current (A) | Connector power (W) | Input power (W) | Efficiency (%) | PF | Current THD (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| PDO5-10W-2A-001 | 4.9963 | 2.00 | 9.99 | 14.78 | 67.61 | 0.62 | 28.37 |
| PDO20-5W-001 | 20.0491 | 0.25 | 5.01 | 8.78 | 57.09 | 0.44 | 79.46 |
| PDO20-75W-001 | 19.9909 | 3.70 | 73.97 | 95.88 | 77.15 | 0.97 | 2.23 |
| PDO20-76W-38A-001 | 19.9813 | 3.80 | 75.93 | 98.99 | 76.70 | 0.98 | 2.62 |
| PDO20-80W-40A-001 | 19.9732 | 4.00 | 79.89 | 104.42 | 76.51 | 0.99 | 3.98 |

Each row is matched by test ID to `/workspace/thesis/Data/measurements/processed_rewrite/power_quality_logged.csv`; the displayed rounded power and efficiency values agree with `/workspace/thesis/Data/measurements/processed_rewrite/efficiency_table.tex`. USB-C voltage is logged mean VBUS, connector power is VBUS times load current, and efficiency estimate is connector power divided by input power. Input power is rounded to the table precision, so calculating the ratio from visible rounded values can differ slightly from the displayed estimate.

At 4 A the primary displayed THD is 3.98%; the reconstruction from the recorded harmonic table is about 4.53%, as described once in the backup notes and in `/workspace/thesis/Chapters/10_Results/07_Input_Power_Quality.tex`. The 3.9 A row is excluded because its associated input record repeats a prior measurement. The 5 V, 2 A row provides another voltage setting with all seven values available; the four 20 V rows correspond to the main input-quality comparison. Input/output simultaneity and all auxiliary power paths were not fully documented, so efficiency remains an initial estimate, as explained in `/workspace/thesis/Chapters/10_Results/08_Efficiency.tex`.

No other slides or source files were edited.

Revision 2: aligned the last speaker-notes sentence with the accepted main-slide wording. Table and THD comparison are unchanged.
