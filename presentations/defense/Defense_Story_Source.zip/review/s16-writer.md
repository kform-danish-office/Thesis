# s16 writer factual review

- The seven chart points were checked against `summary.csv`, with calculated secondary power rounded to two decimals. R1 rises from 50.3 to 98.3 °C. R3 peaks at 83.9 °C at 70.75 W and later reads 68.2–75.6 °C.
- The thesis says that none of the points reached equilibrium; the sequence combines load changes and continued heating. It does not support a continuous rating. Region maxima are not junction temperatures. The proposed interpretation identifies secondary rectifier current and thermal paths.
- The actual final thermal image was inspected. It displays R1 high 98.3 °C and R3 high 73.7 °C, with a colour scale that tops at 85.1 °C; the scale is retained as recorded. Region emissivity 0.95 and footer 0.97 are also retained.
- Two short visible bullets total 14 words. The editable chart makes measurement locations, units, data and tick labels explicit. Slide s15 supplies the electrical droop result; s17 will conclude the measured contribution.
- Source: `/workspace/thesis/Chapters/10_Results/17_V2_Secondary_Load_Tests.tex`; `/workspace/thesis/Data/measurements/v2_load_thermal/summary.csv`; `/workspace/presentations/defense/dtu-supervisor-story/assets/thermal_final.jpg`. Prior proposal `dtu-circuit-story-revised/proposals/c15.json` was checked for continuity.

- Revision 2 shortens the equilibrium statement on the slide and in the notes as requested. The plot and notes retain the non-monotonic R3 sequence.
