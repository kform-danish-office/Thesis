# b04 writer review

The original design calculation combines 9.4 µH external inductance with 16.5 µH transformer leakage and assumes 1 nF, producing 0.9889407 MHz. The modified V2 calculation uses 16.46 µH leakage and approximately 1.66 nF, producing 0.9628335 MHz. The 16.46 µH value is the mean of the supplied 16.42 and 16.50 µH component measurements; the fitted variant is unknown. The original 1 nF is a design value, not a confirmed prior fitted capacitance.

Both results are ideal series LC calculations; the 1 MHz carrier is identified separately and the in-circuit resonance remains to be measured. Neither calculation is presented as proof of commutation or ZVS. This supports the main s14 tank-change slide without repeating its heating and timing explanation. The proposed slide uses an editable equation and two columns; it contains no PCB image. The backup is excluded from the main timing and takes approximately 60 seconds when presented.

Revision 2: The visible caption is shortened to “Ideal series resonance”; the measurement point remains in the notes. The transition is null because the backup slides are used independently for questions.
