# s07 writer review

- The current V2 schematic excerpts were inspected. VSW feeds both the charge-pump branch and the C26/L4/T1 resonant path; the T1 secondary nets feed the four-device rectifier and bulk capacitor.
- The proposal uses the directions iSW into VSW and ipump and itank away from VSW, so iSW = ipump + itank is a signed instantaneous node-current sum. Both branch currents participate in commutation; the illustration must retain those arrows.
- Transformer leakage is a characteristic of T1, not a separate fitted inductor. The drawing shows L4 as in the schematic, while the later V2 change is reserved for s14.
- The MCU regulates the secondary bulk and the PD stage regulates selected VBUS. Avoid drawing a direct conductor across the isolation barrier for the MCU control annotation.
- Figures are schematic excerpts, not photographs. Crop and join the transformer secondary to the bridge by matching LLC_HIGH and LLC_LOW; retain readable labels and actual connectivity.
- Source claims are mapped in the proposal. No unresolved factual question was found. Timing is an estimate for 90 seconds including transition.

## Revision 2

The figure is now specified as a native editable primary-referred equivalent to improve legibility. Transformer leakage appears once as Llk ahead of ideal T1; separate primary and secondary returns, rectifier AC connections, bulk capacitor and PD input are specified explicitly. Current arrows and their signed sum remain. The original V2 schematic remains the source, with its full view reserved for b05. Speaker notes and transition remain unchanged.

## Revision 3

Caption identifies the schematic as a simplified primary-referred equivalent; the magnetizing branch and parasitics are omitted for the overview.
