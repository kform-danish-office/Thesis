"""Package the editable deck and reproducible local source for download."""
from pathlib import Path
import hashlib,json,shutil,zipfile
R=Path(__file__).resolve().parent;NAME='Thesis_Defense_Supervisor_Story'
assets=['adapter_5w.jpg','adapter_20w.jpg','adapter_140w.jpg','v1_scope_5v_3a.png','v1_scope_20v_4a.png','v1_scope_20v_4p7a.png','thermal_final.jpg','schematic_pump_detail.png','v2_complete_power_schematic.png','v2_complete_power_schematic.pdf','v2_schematic.pdf','v1_efficiency.csv','v1_dc_operating_points.csv','v1_power_quality.csv','v2_summary.csv']
files=[R/n for n in ['README.md','requirements.txt','Speaker_Notes.md','build_defense.py','deck_tools.py','circuit_tools.py','chart_tools.py','legacy_layouts.py','render_defense.py','validate_defense.py','package_defense.py']]
files += [R/'assets'/n for n in assets]
files += [R/'template'/n for n in ['DTU Template 16_9 - Blue EN.potx','DTU_Blue_base.pptx']]
files += sorted((R/'proposals').glob('*.json'))
files += [p for p in (R/'review').glob('*') if p.is_file() and p.suffix in ['.json','.md','.jpg'] and not p.name.startswith('adapter-source-discovery')]
assert (R/'review/final-review.json').exists(),'Astra final visual review must be recorded before packaging.'
review=json.loads((R/'review/final-review.json').read_text())
validation=json.loads((R/'review/validation.json').read_text())
assert validation['slides']==22 and validation['package_crc']=='passed'
source=R/(NAME+'_Source.zip')
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(set(files)):z.write(p,p.relative_to(R))
with zipfile.ZipFile(source) as z:assert z.testzip() is None
short=Path('/workspace')
for ext in ['pptx','pdf']:shutil.copy2(R/(NAME+'.'+ext),short/('Defense_Story.'+ext))
shutil.copy2(source,short/'Defense_Story_Source.zip')
bundle=short/'Defense_Story.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.write(short/'Defense_Story.pptx','Defense_Story.pptx')
    z.write(short/'Defense_Story.pdf','Defense_Story.pdf')
    z.write(R/'Speaker_Notes.md','Speaker_Notes.md')
    z.write(source,'Build_Source.zip')
    z.writestr('OPEN_THIS_FIRST.txt','Open Defense_Story.pptx for the editable presentation and speaker notes.\nDefense_Story.pdf is the preview. The deck has 17 main slides and five backup slides.\nThe main speaking allocation is approximately 25 minutes. Rehearse with the notes.\nBuild_Source.zip contains the assembly scripts, source assets and review records.\n')
with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
outputs=[]
for p in [short/'Defense_Story.pptx',short/'Defense_Story.pdf',short/'Defense_Story_Source.zip',bundle]:
    p.chmod(0o644);outputs.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'review/downloads.json').write_text(json.dumps(outputs,indent=2)+'\n')
print(json.dumps(outputs,indent=2))
