# DTU thesis defense — revised circuit story

Editable PowerPoint for a 25-minute talk, followed by five backup slides for questions. The original DTU Blue 16:9 template is retained. Speaker notes contain the explanation and transitions; the separate notes file includes the planned timing.

The main story moves from compact USB adapters to the switching-frequency tradeoff, ZVS operating principle, charge-pump PFC circuit, implemented MCU burst control, and measured V1/V2 results. The measured V1 switching image has no gate timing and is described as approximately 1 MHz operation. USB-C connector power and secondary-load power are kept separate. No V2 scope data is used.

The presentation includes seven editable charts and three editable tables. Circuit diagrams, arrows and text are editable. Scope and thermal images retain their original pixels; selected views use PowerPoint's native cropping. The schematic appendix includes the complete upper power-circuit panels from the colour V2 sheet. The matching vector PDF is included in assets for zooming.

## Files

- `Thesis_Defense_Supervisor_Story.pptx`: presentation with notes.
- `Thesis_Defense_Supervisor_Story.pdf`: rendered preview.
- `Speaker_Notes.md`: notes and timing estimates.
- `build_defense.py`, `deck_tools.py`, `circuit_tools.py`, `chart_tools.py`, `legacy_layouts.py`: reproducible assembly.
- `render_defense.py`: LibreOffice PDF and per-slide previews.
- `validate_defense.py`: text, notes, data, template, image-integrity and bounds checks.
- `proposals/`: accepted slide text and source references.
- `review/`: Astra judgments, slide manifest and verification records.
- `assets/`: local presentation images, measurement tables and vector schematic.
- `template/`: supplied DTU template and the derived base PowerPoint.

## Build

Tested on Linux with Python 3, LibreOfficeDev 26.8, and Liberation Sans installed. The deck requests Arial; the PDF renderer used metric-compatible Liberation Sans. No Microsoft PowerPoint native inspection was performed.

```bash
python -m pip install -r requirements.txt
python build_defense.py
python render_defense.py
python validate_defense.py
```

The build uses only local assets. `deck_tools.py` currently measures text with the Linux Liberation Sans font path; adjust that path when building on another operating system. Opening and editing the supplied PowerPoint does not require Python or the build scripts. Validation checks the thesis against its baseline only when the original thesis directory is accessible.

Timing is a rehearsal estimate, including circuit walkthroughs and pauses. The main allocation is 1500 seconds. Backup slides are outside that allocation.

## Image sources

Apple adapter photographs are manufacturer product images, credited in slide 2 notes. Source URLs and download metadata are in `review/adapter-photo-downloads.json`. These are product examples and are not drawn at a common physical scale. The circuit and experimental images come from the thesis source materials. No measured image was generatively retouched.

All 22 slides were assigned to separate GPT-6.1 Terra ultra writers and judged by the Astra ultra task master. Root assembled the deck, checked measurement values and reviewed the rendered layout. No thesis, firmware or Git reference source was changed, and nothing was committed, pushed or published.
