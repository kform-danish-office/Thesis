# USB-C power supply defense

Editable PowerPoint in the supplied DTU Blue 16:9 template, with presenter notes and a PDF preview. The main talk has 15 slides with an estimated 25-minute speaking allocation; four supporting slides follow the conclusion.

The story begins with compact USB-C adapter demand, explains the frequency/loss tradeoff and the circuit choice, then follows the implemented control into measured switching and output performance. The V2 tank change follows the heating found during testing, with secondary voltage and thermal results completing the design discussion.

## Build

Install Python packages from `requirements.txt`. LibreOffice is needed to render the PDF. Arial is requested by the template; Liberation Sans is used as the metric-compatible font when rendering in this environment.

```sh
python build_defense.py
python render_defense.py
python validate_defense.py
python package_defense.py
```

The generated files are `Thesis_Defense_Supervisor_Flow.pptx` and `.pdf`. Slides and notes are defined in `proposals/`; their order and timing are in `manifest.json`. Electrical diagrams, text, tables and data charts remain editable. Scope screenshots and the thermal frame retain their original pixels; cropping is native to PowerPoint. The supplied template's masters, layouts and theme are preserved.

The complete V2 power schematic is available as a vector PDF in `assets/` for zooming during questions. Adapter photography is credited to Apple, with source URLs in `review/adapter-photo-downloads.json`.

Timing is a speaking allocation, not a timed rehearsal. The complete deck was rendered and visually reviewed using LibreOffice. Native Microsoft PowerPoint inspection was not available.
