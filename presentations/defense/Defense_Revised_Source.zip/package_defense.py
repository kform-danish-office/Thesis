"""Create the presentation download and its reproducible local build source."""
from pathlib import Path
import hashlib,json,shutil,zipfile
R=Path(__file__).resolve().parent;NAME='Thesis_Defense_Focused'
assert (R/'review/final-review.json').exists(),'Final visual and narrative review must be saved first.'
validation=json.loads((R/'review/validation.json').read_text());assert validation['slides']==17 and validation['main_slides']==13
files=[R/n for n in ['README.md','requirements.txt','manifest.json','Speaker_Notes.md','build_defense.py','deck_tools.py','circuit_tools.py','chart_tools.py','master_circuit.py','prior_layouts.py','legacy_layouts.py','render_defense.py','validate_defense.py','package_defense.py']]
files+=[R/'assets'/n for n in ['v1_scope_5v_3a.png','v1_scope_20v_4p7a.png','thermal_final.jpg','v2_complete_power_schematic.png','v2_complete_power_schematic.pdf','v2_schematic.pdf','v1_dc_operating_points.csv','v1_power_quality.csv','v1_efficiency.csv','v2_summary.csv']]
files+=[R/'template'/n for n in ['DTU_Blue_base.pptx','DTU Template 16_9 - Blue EN.potx']]
files+=sorted((R/'proposals').glob('*.json'))
files+=[p for p in (R/'review').glob('*') if p.is_file() and p.suffix in ['.md','.json','.jpg'] and 'draft' not in p.name]
source=R/(NAME+'_Source.zip')
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,p.relative_to(R))
with zipfile.ZipFile(source) as z:assert z.testzip() is None
root=Path('/workspace')
for ext in ['pptx','pdf']:shutil.copy2(R/(NAME+'.'+ext),root/('Defense_Revised.'+ext))
shutil.copy2(source,root/'Defense_Revised_Source.zip')
with zipfile.ZipFile(root/'Defense_Revised.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(root/'Defense_Revised.pptx','Defense_Revised.pptx')
 z.write(root/'Defense_Revised.pdf','Defense_Revised.pdf')
 z.write(R/'Speaker_Notes.md','Speaker_Notes.md')
 z.write(source,'Build_Source.zip')
 z.writestr('OPEN_THIS_FIRST.txt','Open Defense_Revised.pptx for the editable presentation and speaker notes.\nThere are13main slides for an approximately25-minute talk, followed by four backups.\nThe PDF is a preview. Build_Source.zip contains the scripts, assets and reviews.\n'.replace('are13main','are 13 main').replace('approximately25-minute','approximately 25-minute'))
with zipfile.ZipFile(root/'Defense_Revised.zip') as z:assert z.testzip() is None
records=[]
for n in ['Defense_Revised.pptx','Defense_Revised.pdf','Defense_Revised.zip','Defense_Revised_Source.zip']:
 p=root/n;p.chmod(0o644);records.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'review/downloads.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
