# Thesis defense — focused revision

Editable DTU Blue PowerPoint with 13 main slides and four backup slides. The main speaking allocation is approximately 25 minutes, including the circuit walkthroughs. Speaker notes carry the explanation and physical transitions between slides.

The story is now: a USB-C load that changes demand → the shared power circuit → charge-pump input shaping and resonant transfer → secondary-voltage burst control → V1 connector behavior and power losses → the V2 tank change → voltage droop and heating at higher secondary load. The repeated master schematic stays at the same coordinates while the discussed branch is highlighted. Detailed switching and resonance calculations are in the backup section.

The original thesis, firmware and measured images are preserved. USB-C connector power and direct-secondary power remain distinct. Scope images use PowerPoint's native crop; the original bytes remain embedded. The conceptual schematic is editable, as are the six charts and two tables.

## Rebuild

Tested on Linux with Python 3 and LibreOfficeDev 26.8. Arial is requested by the template; the preview was rendered using metric-compatible Liberation Sans. Microsoft PowerPoint native inspection was not performed.

```bash
python -m pip install -r requirements.txt
python build_defense.py
python render_defense.py
python validate_defense.py
```

`deck_tools.py` uses the Linux Liberation Sans font path to estimate text wrapping. Adjust that path when rebuilding on another operating system. Opening the supplied PowerPoint does not require Python. All build assets are local.

The build is assembled from accepted per-slide proposals. Astra ultra judged the story and all rendered slides, with a separate GPT-6.1 Terra ultra writer assigned to each slide. Review records are in `review/`; `manifest.json` records the order, ownership, sources and timing. These files are build records and are not part of the spoken presentation.

The current colour V2 circuit is included as a high-resolution backup and a vector PDF in `assets/` for zooming during questions. Individual component values in the whole-circuit overview need zooming. Source references are in the proposals and speaker notes.
