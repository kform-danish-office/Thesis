# Charge-pump PFC USB-C thesis — rewritten October 2026

This is the editable source of Richard Xu's thesis. The complete text, result
figures, measurement appendix, V1.0/V1.1 schematics, and the V2 F410 drawing
are included. The thesis also reproduces both complete firmware versions and
the complete supporting software source in line-numbered appendices.

The October 20 narrative revision follows the engineering development from the
inherited converter and supplied magnetics through hardware integration,
feedback and timing changes, detachable-load control, measured results, and
the later V2/V3 work. It uses direct first-person American English while
preserving the technical equations, figures, tables, citations, and source code.

## Compile

Upload the source ZIP to Overleaf, select `main.tex`, and use **XeLaTeX**.
The reference list uses `thebibliography`; Biber is not required. The complete
project was compiled locally with Tectonic. Author and submission metadata are
in `Setup/Statics.tex`. The current date reflects the October submission plan.

## Measurement data and figures

- Original workbooks and instrument images: `Data/measurements`.
- Completed electrical, AC-detail, harmonic, thermal, and transient tables:
  Appendix E and `Data/measurements/processed_rewrite`.
- Original waveform copies and their SHA-256 register: `processed_rewrite/raw_waveforms`
  and `raw_waveform_index.csv`.
- Eight rebuilt figures, each as vector PDF and PNG:
  `Pictures/Thesis/10_Results/Rebuilt`.
- Four vector schematic excerpts: `Pictures/Thesis/07_Hardware/Rebuilt`.
- Full V1.0 and V1.1 schematic PDFs: `Pictures/Thesis/07_Hardware`, also reproduced
  in Appendix B.
- Final firmware snapshot: `Code/thesi_power_control_PWR_1_9_20.ino`.

`Data/analysis/rebuild_results.py` regenerates the charts and data tables with
Python, NumPy, and Matplotlib. Run it from any directory:

```text
python Data/analysis/rebuild_results.py
```

The included raw copies are used when the original local acquisition folders
are unavailable. They retain the exported samples and offsets. No waveform is
rescaled to force a target line voltage or input power. Detailed processing
choices are recorded in `processing_provenance.txt` and `figure_manifest.json`.

## Interpretation

The measured assembly is the V1.0 PCB with rework, not a separately manufactured
V1.1 board. The thesis separates drawing changes, fitted hardware, inherited
magnetic design, and original integration/control work. Inconsistent input-power
records, AC statistic ranges, unverified raw-channel calibration, and absent
thermal endurance measurements are identified in the results and appendix.
Planned test rows are retained in the CSV register but are not measurements.

## Language

Use American English throughout the thesis and defense materials.

## V2 and complete source

Project V2 is the development described in the October plan and the later
STM32F410 schematic. Its full four-sheet drawing is in Appendix B. The plan's
reported approximately 85 W baseline is kept separate from the matched
79.89 W result on the earlier V1.0 assembly. Neither establishes the 100 W
continuous target.

- Controller implementation and commands: Appendix C.
- Browser, build, test, and analysis documentation: Appendix G.
- Complete PWR-1.9.20 and PWR-2.0.1 firmware: Appendix H.
- Complete supporting software, test, and analysis files: Appendix I.
- Frozen V2 software: `Code/PWR_2_0_1`.
- File identities, physical line counts, and SHA-256 checksums:
  `Code/source_manifest.json`.

The full listings read the frozen files directly, without selecting line
ranges. Generated build products, third-party libraries, and intermediate
historical duplicates are not separate source implementations. The captured
calculator page is incomplete: its imported UI module was absent and the
bench application's build and local server did not include it. Its calculation
tests do not establish a working calculator page.

The frozen PWR-2.0.1 source compiled for both STM32F410 and STM32G071. The F410
HEX passed the vector, checksum, and reserved-settings-sector checks. All 38
browser/module tests and the production protocol host tests passed. These
software checks do not verify physical UART, sensing calibration, flash writes
on a board, gate timing, or powered-converter performance.

## Revised July–October plan

The revised July 27–October 27, 2026 plan is incorporated into the introduction,
requirements, modeling, hardware, methods, results, discussion, and conclusions.
Chapter 3 defines criteria AP-01–AP-08; Chapter 10 assesses them against the
available records. Appendix J connects the planned milestones to the chapters.
The original plan source and its 14-page PDF remain in `Data/project_records`.
The earlier working draft is retained there as `Original_Project_Definition.tex`.

The current plan sets a 65 W continuous minimum and a 100 W continuous target.
The 75 W figure is retained as an earlier validation milestone. The reported
approximately 85 W V2 baseline needs its own repeatable, matched test record;
the reconstructed measured result remains 79.89 W on the modified V1.0 assembly.
The 15 W planning shortfall, 20.11 W shortfall from that matched result, and
24.53 W screening input–output difference are separate quantities.

The V3 edge-card design brief, release checks, V2/V3 volume method, PDO/PPS tests,
and extended thermal/stability work are documented with their current evidence
status. Scheduled dates do not establish completion. No V3 build, continuous
rating, or numeric V2/V3 power-density improvement is inferred from the plan.
