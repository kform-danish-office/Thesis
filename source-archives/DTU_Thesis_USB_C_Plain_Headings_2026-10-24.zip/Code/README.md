# Code folder

Store versioned exports or links for:

- Firmware V0 open loop
- Firmware V1 blocking-ADC closed loop
- Firmware V2 DMA-based closed loop
- LTspice models and netlists
- MATLAB/Python post-processing scripts

Do not place inherited COMSOL/MATLAB magnetics code here as original work. Put it in a clearly marked `Inherited` folder with provenance and licence information if it must be archived.
