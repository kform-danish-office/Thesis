import { DeviceLink } from './serial.js';
import { openStore, saveSession, listSessions, getSession, deleteSession, toCSV, download } from './storage.js';

const $ = (id) => document.getElementById(id);
const link = new DeviceLink();
const keys = ['VSET', 'VON', 'VMAX', 'OVP', 'DMAX', 'OD', 'FEN'];
const dirty = new Set();
const history = [];
const terminalLines = [];
const unsaved = new Map();
let latest = null;
let lastReceived = 0;
let previousReceived = 0;
let intervalEstimate = 0;
let hello = null;
let chartKind = 'voltage';
let modeDirty = false;
let commandCount = 0;
let applyGeneration = 0;
let recording = null;
let lastRecording = null;
let sessions = [];
let chartQueued = false;
let source = null;
let lastStale = false;
let terminalDirty = false;
let checkpointPromise = null;
let checkpointFailed = false;
const canvas = $('live-chart');
const ctx = canvas.getContext('2d');

const isLive = () => link.state === 'connected' || link.state === 'demo';
const isFresh = () => !!latest && performance.now() - lastReceived < 3000;
const isReady = () => isLive() && !!link.isReady && isFresh();
const faultActive = (fault) => ![null, undefined, false, 0, '', '0', 'NONE', 'none', 'OK', 'ok', 'CLEAR', 'clear'].includes(fault);
const fmt = (value, places = 1) => value !== null && value !== undefined && Number.isFinite(Number(value)) ? Number(value).toFixed(places) : '—';
const duration = (ms) => {
  const total = Math.max(0, Math.floor(ms / 1000));
  return [Math.floor(total / 3600), Math.floor(total / 60) % 60, total % 60].map(value => String(value).padStart(2, '0')).join(':');
};
const actualMode = (value) => String(value || '').toUpperCase();
const modeCommand = (value) => ({ VSB: 'VSBONLY', 'VSB+VIN': 'LINEFF', VINFF: 'LINEFF' }[actualMode(value)] || actualMode(value));
const clone = (value) => JSON.parse(JSON.stringify(value));

function notify(message, success = false) {
  $('alert-text').textContent = String(message);
  $('app-alert').classList.toggle('success', success);
  $('app-alert').hidden = false;
}

function feedback(message, type = '') {
  $('command-feedback').textContent = message;
  $('command-feedback').className = `command-feedback ${type}`;
}

function clearLiveData() {
  latest = null;
  lastReceived = 0;
  previousReceived = 0;
  intervalEstimate = 0;
  hello = null;
  $('firmware-label').textContent = 'Awaiting firmware identification';
  history.length = 0;
  dirty.clear();
  modeDirty = false;
  keys.forEach((key) => { $('setting-' + key).value = ''; $('setting-' + key).closest('label').classList.remove('dirty'); });
  $('mode-select').value = '';
  renderLive();
  queueChart();
}

function renderState(message = '') {
  const state = link.state;
  const live = isLive();
  const demo = state === 'demo';
  $('demo-banner').hidden = !demo;
  canvas.setAttribute('aria-label', `${chartKind === 'duty' ? 'Applied duty' : 'Primary and secondary voltage'} over the last sixty seconds${demo ? ', synthetic demo data' : ''}`);
  $('connection-dot').className = `status-dot ${demo ? 'demo' : state === 'connected' ? 'live' : ''}`;
  $('side-dot').className = $('connection-dot').className;
  $('side-state').replaceChildren(document.createTextNode(demo ? 'SIMULATOR' : state === 'connected' ? 'USB CONNECTED' : state === 'connecting' ? 'CONNECTING' : state === 'disconnecting' ? 'DISCONNECTING' : 'DISCONNECTED'));
  const sideSmall = document.createElement('small');
  sideSmall.textContent = demo ? 'Synthetic data' : '115200 · 8N1';
  $('side-state').append(sideSmall);
  $('connection-label').textContent = demo ? 'Demo · synthetic data' : state === 'connected' ? 'USB connected' : state === 'connecting' ? 'Opening serial port…' : state === 'disconnecting' ? 'Disabling output and closing port…' : 'No USB connection';
  $('connection-detail').textContent = message || (demo ? 'Controls affect the simulator only.' : state === 'connected' ? 'Waiting for verified firmware telemetry.' : state === 'connecting' ? 'Choose your adapter in the browser connection dialog.' : 'Connect your USB-UART adapter to begin.');
  $('connect-button').replaceChildren();
  const connectText = document.createElement('span');
  connectText.textContent = state === 'connected' ? 'Disconnect' : state === 'connecting' ? 'Connecting…' : state === 'disconnecting' ? 'Disconnecting…' : 'Connect USB';
  $('connect-button').append(connectText);
  $('connect-button').disabled = state === 'connecting' || state === 'disconnecting';
  $('demo-button').textContent = demo ? 'Exit demo' : 'Demo';
  $('demo-button').disabled = state === 'connecting' || state === 'disconnecting';
  if (!live) feedback(state === 'connecting' ? 'Opening connection. Output is not enabled automatically.' : 'Waiting for verified telemetry.');
  renderLive();
}

function setHello(detail) {
  hello = clone(detail);
  const firmware = hello.firmware || hello.version || hello.fw || 'Verified firmware';
  $('firmware-label').textContent = `${firmware}${hello.board ? ` · ${hello.board}` : ''}`;
}

function updateControls() {
  const ready = isReady();
  const busy = commandCount > 0;
  $('output-on').disabled = !ready || busy || !!latest?.enabled || faultActive(latest?.fault);
  $('output-off').disabled = !isLive();
  $('mode-select').disabled = !ready || busy;
  $('apply-mode').disabled = !ready || busy || !modeDirty || !$('mode-select').value;
  $('clear-fault').disabled = !ready || busy;
  $('terminal-command').disabled = !isLive() || busy;
  $('send-command').disabled = !isLive() || busy;
  keys.forEach((key) => {
    $('setting-' + key).disabled = !ready || busy || latest?.settings?.[key] === undefined;
  });
  $('apply-settings').disabled = !ready || busy || dirty.size === 0;
  $('reset-settings').disabled = busy || dirty.size === 0;
  $('save-device-settings').disabled = !ready || busy || !!latest?.enabled || !latest?.settings_pending;
  $('record-button').disabled = !recording && !ready;
  $('experiment-name').disabled = !!recording;
  $('settings-status').textContent = dirty.size ? `${dirty.size} edited ${dirty.size === 1 ? 'value' : 'values'} · not applied` : latest?.settings ? 'Actual values reported by device' : 'Device values load after connection';
  $('device-save-status').textContent = latest?.settings_pending ? `Device settings are not saved to flash.${latest.enabled ? ' Turn output OFF before saving.' : ' Save to device to retain them after power cycling.'}` : 'Apply changes to the running configuration; save to device flash with output OFF.';
}

function renderLive() {
  const stale = !!latest && !isFresh();
  $('metric-vsec').textContent = fmt(latest?.vsec);
  $('metric-vpri').textContent = fmt(latest?.vpri);
  $('metric-current').textContent = fmt(latest?.current, 3);
  $('metric-duty').textContent = fmt(latest?.duty, 1);
  $('metric-duty-detail').textContent = latest ? `${actualMode(latest.mode) || 'Unknown mode'} · ${stale ? 'last reported value' : 'reported duty'}` : 'Waiting for reported duty';
  const fault = faultActive(latest?.fault);
  $('metric-fault').textContent = !latest ? 'No data' : stale ? 'Data stale' : fault ? 'Fault active' : 'No faults';
  $('metric-fault').className = `health-value ${latest && fault ? 'fault' : latest && !stale ? 'ok' : ''}`;
  $('metric-fault-detail').textContent = !latest ? 'Fault state unconfirmed' : fault ? `Reported: ${String(latest.fault)}` : stale ? 'Connection controls are restricted' : 'Device-reported fault state';
  $('output-badge').textContent = !latest ? 'UNCONFIRMED' : stale ? 'LAST REPORTED' : fault ? 'FAULT · INHIBITED' : latest.enabled ? 'OUTPUT ON' : 'OUTPUT OFF';
  $('output-badge').className = `badge ${fault ? 'error' : !latest || stale ? 'neutral' : latest.enabled ? 'live' : 'neutral'}`;
  $('output-symbol').classList.toggle('live', !!latest?.enabled && !stale && !fault);
  $('output-state').textContent = !latest ? 'Not connected' : fault ? 'Fault latched · output inhibited' : latest.enabled ? 'Output enabled' : 'Output disabled';
  $('output-description').textContent = !latest ? 'Awaiting device state' : stale ? 'Last reported state; check hardware locally' : link.state === 'demo' ? 'Simulator only' : 'Software enable state reported by firmware';
  $('reported-mode').textContent = `REPORTED: ${actualMode(latest?.mode) || '—'}`;
  if (!modeDirty) $('mode-select').value = modeCommand(latest?.mode);
  $('mode-note').textContent = latest?.enabled ? 'Output is ON. Applying a mode immediately changes control behavior.' : 'Mode changes take effect when acknowledged by the device.';
  if (latest?.settings) keys.forEach((key) => {
    if (!dirty.has(key) && latest.settings[key] !== undefined) $('setting-' + key).value = latest.settings[key];
  });
  if (latest) {
    const elapsed = Math.max(0, (performance.now() - lastReceived) / 1000);
    $('last-update').textContent = stale ? `${Math.floor(elapsed)}s SINCE DATA` : link.state === 'demo' ? 'SYNTHETIC · LIVE' : 'USB · LIVE';
    $('sample-rate').textContent = `${link.state === 'demo' ? 'Synthetic samples' : 'Device samples'}${intervalEstimate ? ` · ~${(1000 / intervalEstimate).toFixed(1)} Hz` : ''}${stale ? ' · stream paused' : ''}`;
    $('adc-values').textContent = `ADC ${Array.isArray(latest.adc) ? latest.adc.join(' / ') : '— / — / —'}`;
  } else {
    $('last-update').textContent = 'NO DATA';
    $('sample-rate').textContent = 'No samples received';
    $('adc-values').textContent = 'ADC — / — / —';
  }
  if (stale && !lastStale && isLive()) {
    $('connection-label').textContent = 'Telemetry paused';
    $('connection-detail').textContent = 'No fresh sample for 3 seconds. Enabling and tuning are restricted.';
    $('connection-dot').className = 'status-dot error';
    if (recording) void stopRecording('Telemetry became stale.');
  } else if (!stale && lastStale && isLive()) {
    $('connection-label').textContent = link.state === 'demo' ? 'Demo · synthetic data' : 'USB connected';
    $('connection-detail').textContent = link.state === 'demo' ? 'Controls affect the simulator only.' : 'Verified telemetry is streaming from firmware.';
    $('connection-dot').className = `status-dot ${link.state === 'demo' ? 'demo' : 'live'}`;
  }
  lastStale = stale;
  $('chart-empty').hidden = history.length > 0;
  updateControls();
}

async function runCommand(command, label = command) {
  recordEvent({type:'command',command,label});
  commandCount += 1;
  feedback(`${label} · waiting for acknowledgment…`, 'pending');
  updateControls();
  try {
    const ack = await link.command(command);
    recordEvent({type:'ack',command,ack});
    feedback(`${label} acknowledged. Actual values follow in telemetry.`);
    return ack;
  } catch (error) {
    const message = `${label}: ${error?.message || error}`;
    recordEvent({type:'command_error',command,message});
    feedback(message, 'error');
    notify(message);
    throw error;
  } finally {
    commandCount = Math.max(0, commandCount - 1);
    updateControls();
  }
}

function recordEvent(event) {
  if (!recording) return;
  if (recording.events.length < 2000) recording.events.push({...clone(event),at:new Date().toISOString()});
  else recording.eventsTruncated = true;
}

link.addEventListener('state', (event) => {
  const nextSource = event.detail.state === 'demo' ? 'demo' : event.detail.state === 'connected' ? 'usb' : null;
  if (recording && (nextSource !== recording.source || !nextSource)) void stopRecording('Connection changed; recording stopped.');
  if (source !== nextSource || !nextSource) clearLiveData();
  source = nextSource;
  if (nextSource && link.hello) setHello(link.hello);
  renderState(event.detail.message || '');
});
link.addEventListener('hello', (event) => {
  setHello(event.detail);
});
link.addEventListener('sample', (event) => {
  latest = clone(event.detail);
  const now = performance.now();
  if (previousReceived) {
    const dt = now - previousReceived;
    intervalEstimate = intervalEstimate ? intervalEstimate * 0.8 + dt * 0.2 : dt;
  }
  previousReceived = now;
  lastReceived = now;
  history.push({ ...latest, received: now });
  while (history.length && (history[0].received < now - 60000 || history.length > 1200)) history.shift();
  if (recording) {
    recording.samples.push({ ...clone(latest), receivedAt: new Date().toISOString() });
    if (recording.samples.length >= 20000) void stopRecording('20,000-sample limit reached. Run saved automatically.');
  }
  renderLive();
  updateRecording();
  queueChart();
});
link.addEventListener('line', (event) => {
  const line = event.detail;
  const at = line.at ? new Date(line.at) : new Date();
  const timestamp = Number.isNaN(at.getTime()) ? new Date().toLocaleTimeString() : at.toLocaleTimeString();
  terminalLines.push(`${timestamp}  ${String(line.direction || 'info').toUpperCase().padEnd(5)} ${String(line.text)}`);
  if (terminalLines.length > 400) terminalLines.shift();
  terminalDirty = true;
  // Keep operator actions and faults in the notebook; the high-volume wire
  // stream remains in samples/terminal and must not crowd out later commands.
  if (line.direction === 'info' || line.direction === 'error') recordEvent(line);
});
link.addEventListener('error', (event) => {
  notify(event.detail?.message || 'The device connection reported an error.');
  feedback(event.detail?.message || 'Connection error', 'error');
});

$('dismiss-alert').addEventListener('click', () => { $('app-alert').hidden = true; });
$('connect-button').addEventListener('click', async () => {
  try {
    if (link.state === 'connected') {
      if (recording) await stopRecording('USB disconnected by user.');
      await link.disconnect();
    } else {
      if (recording) await stopRecording('Switched from demo to USB.');
      if (link.state === 'demo') await link.stopDemo();
      await link.connect();
    }
  } catch (error) { notify(error?.message || String(error)); }
});
async function toggleDemo() {
  try {
    if (recording) await stopRecording('Demo source changed.');
    if (link.state === 'demo') await link.stopDemo();
    else {
      if (link.state === 'connected') await link.disconnect();
      await link.startDemo();
    }
  } catch (error) { notify(error?.message || String(error)); }
}
$('demo-button').addEventListener('click', toggleDemo);
$('exit-demo').addEventListener('click', toggleDemo);
$('output-on').addEventListener('click', () => { if (isReady() && !faultActive(latest?.fault)) void runCommand('ON', 'Enable output').catch(() => {}); });
$('output-off').addEventListener('click', () => { applyGeneration += 1; void runCommand('OFF', 'Output OFF').catch(() => {}); });
$('clear-fault').addEventListener('click', () => { void runCommand('CLR', 'Clear fault').catch(() => {}); });
$('save-device-settings').addEventListener('click', () => {
  if (isReady() && !latest?.enabled) void runCommand('SAVE', 'Save settings to device flash').catch(() => {});
});
$('mode-select').addEventListener('change', () => { modeDirty = $('mode-select').value !== modeCommand(latest?.mode); updateControls(); });
$('apply-mode').addEventListener('click', async () => {
  const mode = $('mode-select').value;
  if (!isReady() || !['OPEN', 'VSBONLY', 'LINEFF'].includes(mode)) return;
  try { await runCommand(mode, `Set ${mode} mode`); modeDirty = false; } catch { /* The device error is already visible. */ }
  updateControls();
});
keys.forEach((key) => $('setting-' + key).addEventListener('input', () => {
  const field = $('setting-' + key);
  if (field.value !== '' && Number(field.value) === Number(latest?.settings?.[key])) dirty.delete(key);
  else dirty.add(key);
  field.closest('label').classList.toggle('dirty', dirty.has(key));
  updateControls();
}));
$('reset-settings').addEventListener('click', () => {
  dirty.clear();
  keys.forEach((key) => { $('setting-' + key).closest('label').classList.remove('dirty'); });
  renderLive();
});
$('settings-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!isReady() || commandCount || !dirty.size) return;
  const edits = keys.filter((key) => dirty.has(key)).map((key) => [key, $('setting-' + key).value]);
  if (edits.some(([, value]) => value === '' || !Number.isFinite(Number(value)))) { notify('Enter a finite number for each edited setting.'); return; }
  const generation = ++applyGeneration;
  // Holding the busy state across the sequence prevents accidental interleaving.
  commandCount += 1;
  updateControls();
  try {
    for (const [key, value] of edits) {
      if (generation !== applyGeneration || !isReady()) throw new Error('Remaining setting changes canceled.');
      await runCommand(`SET ${key} ${Number(value)}`, `Apply ${key}`);
      dirty.delete(key);
      $('setting-' + key).closest('label').classList.remove('dirty');
    }
    feedback(`${edits.length} ${edits.length === 1 ? 'setting' : 'settings'} acknowledged. Telemetry shows applied values.`);
  } catch (error) {
    if (generation !== applyGeneration) feedback('Output OFF requested. Remaining setting changes canceled.');
    else notify(error?.message || String(error));
  } finally { commandCount = Math.max(0, commandCount - 1); updateControls(); }
});

$('terminal-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const input = $('terminal-command');
  const command = input.value.trim();
  if (!command || commandCount || !isLive()) return;
  if (/^ON(?:\s|$)/i.test(command) && (!isReady() || faultActive(latest?.fault))) { notify('Enabling output requires fresh, verified telemetry and no active fault.'); return; }
  try { await runCommand(command, command); input.value = ''; } catch { /* Keep the command available for correction. */ }
});
$('clear-terminal').addEventListener('click', () => { terminalLines.length = 0; terminalDirty = true; });

function updateRecording() {
  const run = recording || lastRecording;
  $('recording-duration').textContent = run ? duration((recording ? Date.now() : new Date(run.endedAt).getTime()) - new Date(run.startedAt).getTime()) : '00:00:00';
  $('recording-samples').textContent = run ? run.samples.length.toLocaleString() : '0';
  $('recording-source').textContent = run ? run.source === 'demo' ? 'DEMO' : 'USB' : '—';
  $('recording-state').textContent = recording ? 'RECORDING' : lastRecording ? 'STOPPED' : 'IDLE';
  $('recording-state').className = `badge ${recording ? recording.source === 'demo' ? 'demo' : 'live' : 'neutral'}`;
  $('record-button').classList.toggle('recording', !!recording);
  $('record-button').replaceChildren();
  const dot = document.createElement('span');
  dot.className = 'record-dot';
  $('record-button').append(dot, document.createTextNode(recording ? 'Stop & save recording' : 'Start recording'));
  updateControls();
}

$('record-button').addEventListener('click', async () => {
  if (recording) { await stopRecording(); return; }
  if (!isReady()) { notify('Connect a verified device or start demo before recording.'); return; }
  const now = new Date();
  recording = {
    id: crypto.randomUUID(),
    name: $('experiment-name').value.trim() || `Experiment · ${now.toLocaleString()}`,
    notes: $('experiment-notes').value.trim(),
    source: link.state === 'demo' ? 'demo' : 'usb',
    startedAt: now.toISOString(),
    endedAt: null,
    firmware: hello ? clone(hello) : null,
    samples: [],
    events: []
  };
  checkpointFailed = false;
  $('recording-note').textContent = recording.source === 'demo' ? 'Recording synthetic demo data. This run will be labeled DEMO in exports.' : 'Recording device telemetry. Notes can be edited while the run is active.';
  updateRecording();
});

async function stopRecording(reason = '') {
  if (!recording) return;
  const completed = recording;
  recording = null;
  completed.endedAt = new Date().toISOString();
  completed.notes = $('experiment-notes').value.trim();
  if (reason) completed.events.push({ direction: 'info', text: reason, at: completed.endedAt });
  lastRecording = completed;
  updateRecording();
  $('recording-note').textContent = 'Saving your recording…';
  try {
    if (checkpointPromise) await checkpointPromise;
    await saveSession(completed);
    $('recording-note').textContent = reason || 'Run saved in this browser. Export a copy from the experiment list.';
    await refreshSessions();
  } catch (error) {
    unsaved.set(completed.id, completed);
    $('recording-note').textContent = 'Browser storage failed. Your run is kept in memory; export it below before closing this tab.';
    notify(`Recording is not saved in browser storage: ${error?.message || error}. Export CSV or JSON below.`);
    renderSessions();
  }
}

function checkpointRecording() {
  if (!recording || checkpointPromise || checkpointFailed) return;
  const snapshot = clone(recording);
  snapshot.notes = $('experiment-notes').value.trim();
  snapshot.checkpointedAt = new Date().toISOString();
  checkpointPromise = saveSession(snapshot).then(() => refreshSessions()).catch((error) => {
    checkpointFailed = true;
    notify(`Automatic checkpoint failed: ${error?.message || error}. Recording continues in memory; stop and export this run before closing the tab.`);
  }).finally(() => { checkpointPromise = null; });
}

async function refreshSessions() {
  try { sessions = await listSessions(); renderSessions(); }
  catch (error) { notify(`Could not read experiment storage: ${error?.message || error}`); renderSessions(); }
}

const element = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};
function renderSessions() {
  const all = [...unsaved.values(), ...sessions.filter((session) => !unsaved.has(session.id))].sort((a, b) => String(b.startedAt).localeCompare(String(a.startedAt)));
  $('session-count').textContent = `${sessions.length} SAVED${unsaved.size ? ` · ${unsaved.size} UNSAVED` : ''}`;
  $('nav-session-count').textContent = String(all.length).padStart(2, '0');
  const list = $('session-list');
  list.replaceChildren();
  if (!all.length) {
    const row = element('tr'); const empty = element('td', 'archive-empty'); empty.colSpan = 6;
    empty.textContent = 'No recorded sessions. Start a recording to save measurements here.';
    row.append(empty); list.append(row);
    return;
  }
  all.forEach((session) => {
    const row = element('tr', 'session-item');
    const name = element('th', 'session-name'); name.scope = 'row';
    const isDemo = session.source === 'demo';
    const incomplete = !session.endedAt;
    const active = recording?.id === session.id;
    const status = unsaved.has(session.id) ? 'UNSAVED' : active ? 'RECORDING' : incomplete ? 'INTERRUPTED' : null;
    name.append(element('strong', '', session.name || 'Untitled experiment'));
    if (session.notes) name.append(element('small', 'session-notes', session.notes.length > 160 ? session.notes.slice(0,160) + '…' : session.notes));
    const sourceCell = element('td', 'session-source');
    sourceCell.append(element('span', `badge ${isDemo ? 'demo' : 'neutral'}`, isDemo ? 'DEMO' : 'USB'));
    if (status) sourceCell.append(element('small', unsaved.has(session.id) ? 'error-label' : '',status));
    const count = session.samples?.length ?? session.sampleCount ?? 0;
    const date = new Date(session.startedAt);
    const elapsed = new Date(session.endedAt || session.checkpointedAt || session.startedAt).getTime() - date.getTime();
    row.append(name,sourceCell,element('td','session-date',date.toLocaleString('en-GB',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'})),element('td','session-duration',duration(elapsed)),element('td','session-samples',count.toLocaleString()));
    const actions = element('td', 'session-actions');
    const csv = element('button', '', 'CSV');
    const json = element('button', '', 'JSON');
    const remove = element('button', 'delete-session', 'Delete');
    remove.disabled = active;
    [csv, json, remove].forEach((button) => { button.type = 'button'; });
    csv.setAttribute('aria-label',`Export CSV for ${session.name || 'Untitled experiment'}`);
    json.setAttribute('aria-label',`Export JSON for ${session.name || 'Untitled experiment'}`);
    remove.setAttribute('aria-label',`Delete ${session.name || 'Untitled experiment'}`);
    csv.addEventListener('click', () => void exportSession(session.id, 'csv'));
    json.addEventListener('click', () => void exportSession(session.id, 'json'));
    let confirming = false;
    remove.addEventListener('click', async () => {
      if (!confirming) {
        confirming = true;
        remove.textContent = 'Confirm delete';
        remove.classList.add('confirm');
        setTimeout(() => { confirming = false; remove.textContent = 'Delete'; remove.classList.remove('confirm'); }, 5000);
        return;
      }
      try {
        if (unsaved.has(session.id)) unsaved.delete(session.id);
        else await deleteSession(session.id);
        await refreshSessions();
      } catch (error) { notify(`Could not delete this run: ${error?.message || error}`); }
    });
    actions.append(csv, json, remove);
    row.append(actions);
    list.append(row);
  });
}

async function exportSession(id, kind) {
  try {
    const session = unsaved.get(id) || await getSession(id);
    if (!session) throw new Error('This recording is no longer available.');
    const name = (session.name || 'experiment').replace(/[^\p{L}\p{N}_-]+/gu, '-').slice(0, 80);
    const prefix = session.source === 'demo' ? 'DEMO-' : 'USB-';
    if (kind === 'csv') download(`${prefix}${name}.csv`, toCSV(session), 'text/csv;charset=utf-8');
    else download(`${prefix}${name}.json`, JSON.stringify(session, null, 2), 'application/json');
  } catch (error) { notify(`Export failed: ${error?.message || error}`); }
}

function queueChart() {
  if (chartQueued) return;
  chartQueued = true;
  requestAnimationFrame(() => { chartQueued = false; drawChart(); });
}

function drawChart() {
  if (!ctx) return;
  const rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(rect.width * dpr);
  canvas.height = Math.round(rect.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const width = rect.width;
  const height = rect.height;
  const pad = { left: 44, right: chartKind === 'voltage' ? 48 : 15, top: 20, bottom: 29 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const fields = chartKind === 'duty' ? [['duty', '#8fc886']] : [['vsec', '#f0d365'], ['vpri', '#67cbd1']];
  const scales = Object.fromEntries(fields.map(([key]) => {
    const values = history.filter(sample => sample[key] != null && Number.isFinite(sample[key])).map(sample => sample[key]);
    const observedMax = values.length ? Math.max(...values) : key === 'vpri' ? 400 : key === 'duty' ? 100 : 40;
    const observedMin = values.length ? Math.min(...values) : 0;
    const step = key === 'vpri' ? 50 : 5;
    const max = key === 'duty' ? 100 : Math.max(step * 2, Math.ceil(observedMax * 1.12 / step) * step);
    const min = observedMin < 0 ? Math.floor(observedMin / step) * step : 0;
    return [key,{min,max}];
  }));
  const y = (value,key) => { const {min,max} = scales[key]; return pad.top + plotH * (1 - (value-min)/(max-min || 1)); };
  const now = performance.now();
  const x = (time) => pad.left + plotW * (1 - (now - time) / 60000);
  ctx.fillStyle = '#12191f'; ctx.fillRect(0,0,width,height);
  ctx.font = '10px Consolas, monospace';
  ctx.fillStyle = '#899aa6';
  ctx.strokeStyle = '#29343e';
  ctx.lineWidth = 1;
  for (let n = 0; n <= 4; n += 1) {
    const yy = pad.top + plotH * n / 4;
    ctx.beginPath(); ctx.moveTo(pad.left, yy); ctx.lineTo(width - pad.right, yy); ctx.stroke();
    fields.forEach(([key,color],index) => {
      const {min,max} = scales[key]; const value = max - (max-min)*n/4;
      ctx.textAlign = index ? 'left' : 'right'; ctx.fillStyle = color;
      ctx.fillText(value.toFixed(value % 1 ? 1 : 0),index ? width-pad.right+8 : pad.left-8,yy+3);
    });
  }
  ctx.textAlign='left'; ctx.fillStyle=fields[0][1]; ctx.fillText(chartKind==='duty' ? '%' : 'V',pad.left-20,11);
  if (fields.length > 1) {ctx.textAlign='right';ctx.fillStyle=fields[1][1];ctx.fillText('V',width-pad.right+20,11);}
  ctx.fillStyle='#899aa6';
  ctx.textAlign = 'center';
  for (let n = 0; n <= 4; n += 1) {
    const xx = pad.left + plotW * n / 4;
    ctx.beginPath();ctx.moveTo(xx,pad.top);ctx.lineTo(xx,height-pad.bottom);ctx.stroke();
    ctx.fillText(n === 4 ? '0 s' : `−${60 - n * 15} s`, xx, height - 9);
  }
  ctx.save();
  ctx.beginPath(); ctx.rect(pad.left, pad.top - 2, plotW, plotH + 4); ctx.clip();
  fields.forEach(([key, color], index) => {
    const valid = history.filter((sample) => sample[key] !== null && sample[key] !== undefined && Number.isFinite(Number(sample[key])));
    if (!valid.length) return;
    ctx.beginPath();
    let previous = null;
    valid.forEach((sample) => {
      const xx = x(sample.received), yy = y(Number(sample[key]),key);
      if (!previous || sample.received - previous > 3000) ctx.moveTo(xx, yy);
      else ctx.lineTo(xx, yy);
      previous = sample.received;
    });
    ctx.strokeStyle = color; ctx.lineWidth = index ? 1.4 : 1.8; ctx.lineJoin = 'round'; ctx.stroke();
    const last = valid[valid.length - 1];
    ctx.beginPath(); ctx.arc(x(last.received), y(Number(last[key]),key), 2, 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill();
  });
  ctx.restore();
}

document.querySelectorAll('[data-chart]').forEach((button) => button.addEventListener('click', () => {
  chartKind = button.dataset.chart;
  document.querySelectorAll('[data-chart]').forEach((other) => { const selected = other === button; other.classList.toggle('selected', selected); other.setAttribute('aria-pressed', String(selected)); });
  const legend = $('chart-legend');
  legend.replaceChildren();
  const entries = chartKind === 'duty' ? [['duty', 'EN duty · %']] : [['green', 'CH1 Vsec · left axis'], ['orange', 'CH2 Vpri · right axis']];
  entries.forEach(([color, label]) => { const span = element('span'); span.append(element('i', color), document.createTextNode(label)); legend.append(span); });
  legend.append(element('span', 'chart-window', '60 s window'));
  canvas.setAttribute('aria-label', `${chartKind === 'duty' ? 'Applied duty' : 'Primary and secondary voltage'} over the last sixty seconds${link.state === 'demo' ? ', synthetic demo data' : ''}`);
  queueChart();
}));

document.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', () => {
  document.querySelectorAll('.nav-link').forEach((other) => other.classList.toggle('active', other === link));
}));
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    document.querySelectorAll('.nav-link').forEach((nav) => nav.classList.toggle('active', nav.getAttribute('href') === `#${visible.target.id}`));
    const name = visible.target.id === 'experiments' ? 'Sessions' : visible.target.id === 'connection-guide' ? 'Connection' : 'Monitor';
    const breadcrumb = document.querySelector('.breadcrumb');
    breadcrumb.textContent = name;
  }, { rootMargin: '-10% 0px -45% 0px', threshold: [0, 0.2, 0.6] });
  ['dashboard', 'experiments', 'connection-guide'].forEach((id) => observer.observe($(id)));
}
if ('ResizeObserver' in window) new ResizeObserver(queueChart).observe(canvas.parentElement);
else window.addEventListener('resize', queueChart);
window.addEventListener('beforeunload', (event) => {
  if (recording || unsaved.size) { event.preventDefault(); event.returnValue = ''; }
});
window.addEventListener('pagehide', () => {
  if (recording) {
    const snapshot = clone(recording);
    snapshot.notes = $('experiment-notes').value.trim();
    snapshot.checkpointedAt = new Date().toISOString();
    void saveSession(snapshot).catch(() => {});
  }
  link.abandon?.();
});

$('browser-support').textContent = 'serial' in navigator && window.isSecureContext ? 'Web Serial available. Select Connect USB, then choose the adapter port. Firmware PWR-2.0.1 or later is required.' : 'USB requires desktop Chrome or Edge with HTTPS or localhost. Demo and saved sessions are available here.';
renderState();
updateRecording();
queueChart();
setInterval(() => {
  renderLive();
  if (recording) updateRecording();
  if (history.length) queueChart();
  if (terminalDirty && $('terminal-details').open) {
    const output = $('terminal-output');
    const nearBottom = output.scrollHeight - output.scrollTop - output.clientHeight < 60;
    output.textContent = terminalLines.join('\n');
    if (nearBottom) output.scrollTop = output.scrollHeight;
    $('terminal-count').textContent = `${terminalLines.length} lines · latest 400 retained`;
    terminalDirty = false;
  }
}, 500);
setInterval(checkpointRecording, 5000);
void (async () => {
  try { await openStore(); await refreshSessions(); }
  catch (error) { notify(`Local experiment storage is unavailable: ${error?.message || error}. Recordings can still be exported from memory.`); }
})();
