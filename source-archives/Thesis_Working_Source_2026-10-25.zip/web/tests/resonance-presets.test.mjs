import test from 'node:test';
import assert from 'node:assert/strict';
import { PRESETS, SOURCES } from '../resonance-presets.js';
import { analyzeTank, equivalentCapacitance } from '../resonance.js';

test('tested thesis preset reproduces the nominal 25.9 uH / 1 nF tank', () => {
  const p = PRESETS.find(p => p.id === 'thesis-tested-nominal');
  const r = analyzeTank({ solveFor:'frequency', discreteInductanceH:p.discreteInductanceUh*1e-6, leakageInductanceH:p.leakageInductanceUh*1e-6, capacitanceF:equivalentCapacitance(p.capacitorsNf.map(c=>c*1e-9),p.capacitorConnection) });
  assert.ok(Math.abs(r.totalInductanceH-25.9e-6)<1e-16);
  assert.ok(Math.abs(r.resonantFrequencyHz-988940.697)<0.001);
  assert.equal(p.capacitorBasis,'documented-equivalent');
});

test('unvalued C26 and leakage remain unknown in drawing-only presets', () => {
  for(const id of ['f410-drawing-values','v11-drawing-values']) {
    const p = PRESETS.find(p=>p.id===id);
    assert.deepEqual(p.capacitorsNf,[]);
    assert.equal(p.leakageInductanceUh,null);
    assert.equal(p.capacitorBasis,'unprovided');
    assert.throws(()=>equivalentCapacitance(p.capacitorsNf,'parallel'));
  }
});

test('borrowed F410 circuit values are explicitly an assumed equivalent', () => {
  const p=PRESETS.find(p=>p.id==='f410-thesis-scenario');
  assert.equal(p.capacitorBasis,'assumed-equivalent');
  assert.match(p.sourceNote,/Neither C26 = 1 nF nor transformer leakage = 16.5/);
  assert.match(SOURCES.schematic12.detail,/C7 = 1 nF.*not C26/);
});

test('every preset has unique identity and valid source references', () => {
  assert.equal(new Set(PRESETS.map(p=>p.id)).size,PRESETS.length);
  for(const p of PRESETS) for(const id of p.sourceIds) assert.ok(SOURCES[id]?.detail,`${p.id}: ${id}`);
  for(const s of Object.values(SOURCES)) if(s.url) assert.equal(new URL(s.url).protocol,'https:');
});
