# Converter test bench

Browser control and experiment logging for the current thesis converter firmware.
The app is a dependency-free static website for Vercel. USB communication runs on
the computer viewing the website; Vercel does not open the serial port. Session
records stay in that browser's IndexedDB and can be downloaded as CSV or JSON.
There is no cloud database, remote access to the bench, or account requirement.

**Live app:** <https://thesis-power-lab.vercel.app>

## Resonant-tank calculator

Open **Calculator** in the navigation. It opens in a separate tab so USB control
and recording can continue in the monitor. Pick a schematic/document preset,
choose frequency, discrete inductance, or equivalent capacitance as the unknown,
then edit the other inputs. Results update immediately. Reload preset restores
its starting values.

Five presets cover the tested V1.0 thesis model, supplied transformer A,
the latest F410 drawing, an explicitly assumed F410 comparison, and V1.1.
Unvalued C26 and unspecified transformer leakage stay blank. A blank leakage
field is explicitly assumed zero; enter the primary-referred value when known.
The 1 nF thesis value is an equivalent tank capacitance, not an inferred physical
capacitor population. Magnetizing L is excluded from series L.

The calculator supports series/parallel capacitor entries, editable design
ranges, reactance or positive-R normalized current plots, E12/E24 comparisons,
and CSV/JSON calculation records. The separate charge-pump panel uses the
thesis triangular-current sizing relation. These calculations do not apply
settings to hardware. See [source evidence and equations](../docs/calculator-evidence.md).

## Start

From this folder, run `node server.mjs`, then open <http://localhost:4173> in
desktop Chrome or Edge. Click **Demo** to inspect the interface with synthetic
data. Demo sessions are marked `demo` in the app and exports.

For USB, build and flash the new **PWR-2.0.1** firmware for your board first:

```powershell
cd C:\Users\multi\Documents\Thesis
.\firmware\build.ps1 -Target F410
# Or: .\firmware\build.ps1 -Target G071
```

Build outputs are `arduino-build-f410/` and `arduino-build-g071/`. For F410,
use the HEX and custom linker from the build script; a BIN spans the reserved
settings sector. Follow [the existing board notes](../docs/stm32f410-port.md)
for flashing and board verification. The app does not flash hardware.

Connect an appropriate **isolated USB-to-3.3 V-UART interface** when the
controller is referenced to the live primary side. An unisolated PC USB ground
must not be connected to a mains-powered primary ground. With the bench
appropriately de-energized, wire:

| Adapter | F410 schematic-12 board | Original G071 |
| --- | --- | --- |
| RX | PA9 TX (J3 pin 5) | PC4 TX |
| TX | PA10 RX (J3 pin 6) | PC5 RX |
| Isolated UART-side reference | Board signal reference | Board signal reference |

Use **115200 baud, 8 data bits, no parity, 1 stop bit, no flow control**.
Close other serial monitors before clicking **Connect USB** and selecting the
adapter's serial port. These boards expose a UART command path; plugging in a
USB cable alone does not add native USB CDC to the firmware.

## Control and logging

- Connection negotiates the web protocol, arms a 5-second communication lease,
  and requests telemetry every 500 ms. Connection does not send ON or apply
  preset settings. Forms use values reported by the board.
- ON requires a negotiated connection, fresh telemetry, a live lease, and no
  reported fault. Commands report rejection/timeout instead of claiming success.
  Device telemetry confirms output and settings; firmware remains authoritative.
- OFF takes priority over queued app commands. Disconnect requests OFF before
  closing the port. On cable removal, tab closure, or suspended browser,
  heartbeat loss causes the firmware to turn output OFF within the active
  lease (normally 5 seconds). This software timeout is not a physical emergency
  disconnect and has not been validated electrically on a powered converter.
- Setting changes apply in RAM. Use explicit SAVE with output OFF to persist
  them in the board's nonvolatile storage. The firmware keeps its existing
  validation/clamping and protections. Legacy tuning and boot-setting commands
  are deliberately unavailable through the web command dispatcher; the UART
  terminal retains those workflows.
- Name a session, enter bench notes, then record. Local sessions include host
  receipt times, device uptime, measurements, settings, source, firmware, and
  command events. CSV provides the samples; JSON also includes events/metadata.
  Export important sessions: browser storage can be cleared or evicted and is
  specific to this browser and website origin.
- PA2 is half-bridge current feedback. The displayed current and derived power
  are **diagnostics**, not calibrated secondary load current/output power.
  The 100 W label is the thesis design target, not a measured performance claim.

Web Serial needs a supported desktop browser and HTTPS or localhost. A browser
without Web Serial can still run Demo and manage local logs. An embedded app
preview may restrict serial access: use the deployment URL in desktop Chrome
or Edge for the actual USB connection.

## Build and deploy to Vercel

```powershell
cd C:\Users\multi\Documents\Thesis\web
node --test tests/*.test.mjs
node build.mjs
```

In Vercel, select **web** as the project root, framework **Other**, build
`node build.mjs`, and output directory `dist`. No install step, secrets,
environment variables, database, or paid integration is required. Alternatively
run the Vercel CLI from this folder using your authorized team/account.
Only the app's eleven static files are included in `dist`; thesis documents,
firmware source, logs, local credentials, and test tools are not deployed.

`vercel.json` supplies a restrictive content policy, local-origin serial
permission, and cache revalidation. The same headers are used locally.

## Implementation

- `app.js`, `index.html`, `styles.css`: dashboard, controls, charts and sessions.
- `serial.js`: real Web Serial transport, correlated acknowledgments, stale-data
  interlock, lease heartbeat, command queue and clearly labeled simulator.
- `protocol.js`: bounded line framing and validated protocol parsing.
- `storage.js`: IndexedDB sessions and spreadsheet-safe CSV export.
- `calculator.html`, `calculator.css`, `resonance-ui.js`: editable calculator UI.
- `resonance.js`: SI-only LC/RLC and separate charge-pump mathematics.
- `resonance-presets.js`: source-backed starting values and explicit unknowns.
- [Protocol specification](../docs/web-protocol.md): firmware commands and frames.

See [verification results](VERIFICATION.md) for the checks actually completed.
